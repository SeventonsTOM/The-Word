const { test } = require("node:test"),
  assert = require("node:assert/strict");
const m = require("../miniprogram/utils/model"),
  demo = require("../miniprogram/data/demo");
const words = () =>
  demo.map((w) => m.validateWord(JSON.parse(JSON.stringify(w))));
const opts = (extra = {}) =>
  Object.assign(
    {
      lists: [demo[0].list],
      includeMastered: false,
      onlyHighlights: false,
      minLevel: "normal",
      repeatDifficult: true,
      shuffle: false,
      mode: "percent",
      amount: 100,
    },
    extra,
  );
test("重复词性与多汉义完整保留，图片五条短语归属不丢失", () => {
  const w = words();
  assert.equal(w[0].branches.length, 2);
  assert.equal(w[0].branches[1].pos, "a.");
  assert.equal(w[0].branches.flatMap((b) => b.phrases).length, 5);
  assert.deepEqual(w[2].branches[0].meanings, ["现代的", "当代的"]);
});
test("顺序抽查先单词后全部短语，再到下一单词", () => {
  const s = m.buildSession(words(), opts());
  assert.equal(s.wordCount, 3);
  assert.equal(s.queue.length, 8);
  assert.deepEqual(
    s.queue.slice(0, 7).map((q) => q.text),
    [
      "ancient",
      "in ancient times",
      "ancient buildings",
      "an ancient Greek philosopher",
      "ancient Hawaiians",
      "an ancient oak tree",
      "antique",
    ],
  );
});
test("仅重点只保留重点单词的重点词义及重点短语，非重点单词整条排除", () => {
  const s = m.buildSession(words(), opts({ onlyHighlights: true }));
  assert.deepEqual(
    s.queue.map((q) => q.text),
    ["ancient", "in ancient times", "ancient buildings", "modern"],
  );
  assert.equal(s.queue[0].answer, "a. 古代的");
  const w = words();
  w[0].branches.forEach((b) => (b.highlight = false));
  const t = m.buildSession(w, opts({ onlyHighlights: true }));
  assert.equal(t.wordCount, 1);
  assert.deepEqual(
    t.queue.map((q) => q.text),
    ["modern"],
  );
  const all = m.buildSession(w, opts({ onlyHighlights: false }));
  assert.equal(all.wordCount, 3);
  assert.equal(all.queue.length, 8, "关闭仅重点恢复普通词义与全部短语");
});

test("仅重点两层条件在全部/自选、随机和加练中一致，短语难度仍独立判断", () => {
  const w = words();
  w[0].branches
    .flatMap((b) => b.phrases)
    .forEach((p) => {
      p.level = "tricky";
    });
  w[0].branches[1].phrases[0].highlight = true;
  w[1].branches[0].phrases.push({
    id: "antique-highlight-phrase",
    text: "an antique vase",
    meaning: "古董花瓶",
    highlight: true,
    level: "stubborn",
  });
  const expected = ["ancient_p1", "ancient_p2", "ancient_p5"];
  for (const mode of ["all", "selected"])
    for (const shuffle of [false, true])
      for (const repeatDifficult of [false, true]) {
        const option = opts({
          mode,
          shuffle,
          repeatDifficult,
          onlyHighlights: true,
          minLevel: "tricky",
          ...(mode === "selected" ? { wordIds: w.map((word) => word.id) } : {}),
        });
        assert.deepEqual(
          m.filterWords(w, option).map((word) => word.id),
          [w[0].id],
        );
        const session = m.buildSession(w, option, () => 0);
        assert.equal(session.wordCount, 1);
        assert.equal(
          session.queue.length,
          expected.length * (repeatDifficult ? 2 : 1),
        );
        assert.ok(
          session.queue.every(
            (q) => q.wordId === w[0].id && q.type === "phrase",
          ),
        );
        assert.deepEqual(
          session.queue
            .filter((q) => !q.repeat)
            .map((q) => q.phraseId)
            .sort(),
          expected,
        );
        assert.ok(
          session.queue
            .filter((q) => q.repeat)
            .every((q) => expected.includes(q.phraseId)),
        );
      }
  w[0].branches.forEach((b) => {
    b.highlight = false;
  });
  assert.throws(
    () => m.buildSession(w, opts({ onlyHighlights: true, minLevel: "tricky" })),
    /没有可抽查/,
  );
});
test("已掌握、最低分级与词表范围同时生效", () => {
  const w = words();
  w[0].mastered = true;
  w[1].level = "tricky";
  assert.equal(m.filterWords(w, opts()).length, 2);
  assert.equal(m.filterWords(w, opts({ includeMastered: true })).length, 3);
  assert.deepEqual(
    m.filterWords(w, opts({ minLevel: "shaky" })).map((w) => w.text),
    ["antique"],
  );
  assert.equal(m.filterWords(w, opts({ lists: [] })).length, 0);
});
test("需加强词只额外出现一次且放在队尾", () => {
  const w = words();
  w[0].level = "shaky";
  const s = m.buildSession(w, opts());
  assert.equal(s.queue.length, 9);
  assert.ok(s.queue.slice(8).every((q) => q.repeat && q.wordId === w[0].id));
  assert.equal(new Set(s.queue.map((q) => q.id)).size, 9);
  assert.equal(
    m.buildSession(w, opts({ repeatDifficult: false })).queue.length,
    8,
  );
});

test("低等级单词的高等级短语可单独入选，重点与分级必须在同一内容上同时满足", () => {
  const w = words()[0];
  const p = w.branches[0].phrases[0];
  p.level = "tricky";
  const option = opts({ minLevel: "tricky" });
  const s = m.buildSession([w], option);
  assert.equal(s.wordCount, 1);
  assert.equal(s.queue.length, 2);
  assert.ok(s.queue.every((q) => q.type === "phrase" && q.phraseId === p.id));
  assert.deepEqual(
    s.queue.map((q) => q.repeat),
    [false, true],
  );
  p.highlight = false;
  assert.equal(
    m.filterWords([w], opts({ minLevel: "tricky", onlyHighlights: true }))
      .length,
    0,
  );
  w.level = "stubborn";
  const t = m.buildSession([w], opts({ minLevel: "stubborn" }));
  assert.ok(t.queue.every((q) => q.type === "word"));
  assert.equal(t.queue.length, 2);
  w.mastered = true;
  assert.equal(m.filterWords([w], option).length, 0);
  assert.equal(
    m.filterWords([w], opts({ minLevel: "tricky", includeMastered: true }))
      .length,
    1,
  );
});

test("四级最低门槛与重点、已掌握、词表取交集，加练不扩大选词范围", () => {
  const levels = ["normal", "shaky", "tricky", "stubborn"];
  const w = levels.map((level) =>
    Object.assign({}, words()[0], { id: level, text: level, level }),
  );
  for (let i = 0; i < levels.length; i++) {
    const option = opts({ minLevel: levels[i], repeatDifficult: true });
    assert.deepEqual(
      m.filterWords(w, option).map((word) => word.level),
      levels.slice(i),
    );
    const session = m.buildSession(w, option);
    assert.equal(session.wordCount, 4 - i);
    assert.ok(session.queue.every((q) => levels.slice(i).includes(q.wordId)));
    assert.ok(
      session.queue.filter((q) => q.repeat).every((q) => q.wordId !== "normal"),
    );
  }
  w[1].list = "未选择的词表";
  w[2].branches = [
    {
      id: "unmarked",
      pos: "n.",
      meanings: ["汉义"],
      highlight: false,
      phrases: [],
    },
  ];
  w[3].mastered = true;
  assert.equal(
    m.filterWords(w, opts({ minLevel: "shaky", onlyHighlights: true })).length,
    0,
  );
  assert.deepEqual(
    m
      .filterWords(
        w,
        opts({
          minLevel: "shaky",
          onlyHighlights: true,
          includeMastered: true,
        }),
      )
      .map((word) => word.id),
    ["stubborn"],
  );
  assert.throws(() => m.filterWords(w, opts({ minLevel: "unknown" })), /分级/);
});

test("新词默认 Normal，旧备份转换分级，显式手动等级不被历史错误覆盖", () => {
  assert.equal(m.blankWord().level, "normal");
  const base = JSON.parse(JSON.stringify(demo[0]));
  delete base.level;
  const legacy = (extra) => m.validateWord(Object.assign({}, base, extra));
  assert.equal(legacy({}).level, "normal");
  assert.equal(legacy({ mistakes: 1 }).level, "shaky");
  assert.equal(legacy({ mistakes: 2, bomb: true }).level, "tricky");
  assert.equal(legacy({ mistakes: 8, bomb: true }).level, "stubborn");
  assert.equal(legacy({ bomb: true }).level, "tricky");
  assert.equal(legacy({ mastered: true, mistakes: 8 }).level, "normal");
  assert.equal(
    legacy({ level: "Normal", mistakes: 8, bomb: true }).level,
    "normal",
  );
  assert.equal(Object.hasOwn(legacy({ bomb: true }), "bomb"), false);
  for (const level of [null, 4, "easy", ""])
    assert.throws(() => legacy({ level }), /分级/);
  const imported = m.parseImport(JSON.stringify([{ ...base, mistakes: 1 }]));
  const roundtrip = m.parseImport(
    JSON.stringify({ schemaVersion: 1, words: imported }),
  );
  assert.equal(roundtrip[0].level, "shaky");
  assert.equal(roundtrip[0].mistakes, 1);
  assert.ok(
    roundtrip[0].branches
      .flatMap((b) => b.phrases)
      .every((p) => p.level === "normal" && p.mistakes === 0),
  );
  const phrase = imported[0].branches[0].phrases[0];
  phrase.level = "stubborn";
  phrase.mistakes = 6;
  const savedPhrase = m.parseImport(JSON.stringify(imported))[0].branches[0]
    .phrases[0];
  assert.equal(savedPhrase.level, "stubborn");
  assert.equal(savedPhrase.mistakes, 6);
  phrase.level = "unknown";
  assert.throws(() => m.parseImport(JSON.stringify(imported)), /分级/);
  phrase.level = "normal";
  phrase.mistakes = -1;
  assert.throws(() => m.parseImport(JSON.stringify(imported)), /短语错误次数/);
});
test("打乱不丢题、不重复普通题，且改变顺序", () => {
  const ordered = m.buildSession(words(), opts()).queue.map((q) => q.text);
  const random = m
    .buildSession(words(), opts({ shuffle: true }), () => 0)
    .queue.map((q) => q.text);
  assert.deepEqual(random.slice().sort(), ordered.slice().sort());
  assert.notDeepEqual(random, ordered);
});

test("自选 ID 精确限定出题集合，打乱不换词、不受旧数量参数截断，空选不退回全书", () => {
  const w = words();
  const option = opts({
    mode: "selected",
    wordIds: [w[2].id, w[0].id, w[0].id],
    amount: 1,
  });
  const session = m.buildSession(w, option);
  assert.equal(session.wordCount, 2);
  assert.deepEqual(
    session.queue.filter((q) => q.type === "word").map((q) => q.text),
    ["ancient", "modern"],
  );
  assert.ok(
    session.queue.every((q) => q.wordId === w[0].id || q.wordId === w[2].id),
  );
  const shuffled = m.buildSession(w, { ...option, shuffle: true }, () => 0);
  assert.deepEqual(
    shuffled.queue.map((q) => q.text).sort(),
    session.queue.map((q) => q.text).sort(),
  );
  assert.throws(
    () => m.buildSession(w, { ...option, wordIds: [] }),
    /没有可抽查/,
  );
  assert.throws(
    () => m.buildSession(w, { ...option, wordIds: ["removed"] }),
    /没有可抽查/,
  );
  assert.throws(
    () => m.buildSession(w, { ...option, lists: [w[0].list, "其他词书"] }),
    /同一本词书/,
  );
  assert.throws(
    () => m.buildSession(w, { ...option, wordIds: "all" }),
    /同一本词书/,
  );
});

test("自选范围同时遵守词书、重点、掌握和单词/短语独立等级，加练不越界", () => {
  const w = words();
  w[0].branches[0].phrases[0].level = "tricky";
  w[1].level = "stubborn";
  w[2].level = "tricky";
  w[2].list = "另一词书";
  const option = opts({
    mode: "selected",
    wordIds: w.map((word) => word.id),
    minLevel: "tricky",
    onlyHighlights: true,
  });
  const session = m.buildSession(w, option);
  assert.equal(session.wordCount, 1);
  assert.equal(session.queue.length, 2);
  assert.ok(
    session.queue.every(
      (q) =>
        q.type === "phrase" && q.phraseId === w[0].branches[0].phrases[0].id,
    ),
  );
  w[0].mastered = true;
  assert.throws(() => m.buildSession(w, option), /没有可抽查/);
  assert.equal(
    m.buildSession(w, { ...option, includeMastered: true }).wordCount,
    1,
  );
  assert.equal(
    m.buildSession(words(), opts({ mode: "all", amount: undefined })).wordCount,
    3,
  );
});
test("比例向上取整，数量指单词而非短语；上限和非法输入校验", () => {
  assert.equal(m.buildSession(words(), opts({ amount: 10 })).wordCount, 1);
  assert.equal(
    m.buildSession(words(), opts({ mode: "count", amount: 1 })).queue.length,
    6,
  );
  assert.equal(
    m.buildSession(words(), opts({ mode: "count", amount: 99 })).wordCount,
    3,
  );
  for (const amount of [0, -1, 101, "x"])
    assert.throws(() => m.buildSession(words(), opts({ amount })));
  assert.throws(() =>
    m.buildSession(words(), opts({ mode: "count", amount: 1.5 })),
  );
  assert.throws(() => m.buildSession([], opts()));
});
test("导入导出可往返，重复 ID / 同表同名 / 非法结构拒绝", () => {
  const w = words();
  assert.equal(
    m.parseImport(JSON.stringify({ schemaVersion: 1, words: w })).length,
    3,
  );
  assert.throws(() =>
    m.parseImport(JSON.stringify({ schemaVersion: 2, words: w })),
  );
  assert.throws(() => m.parseImport(JSON.stringify([w[0], w[0]])));
  const bad = JSON.parse(JSON.stringify(w[0]));
  bad.branches[0].phrases[0].meaning = "";
  assert.throws(() => m.validateWord(bad));
  const dupe = JSON.parse(JSON.stringify(w[0]));
  dupe.id = "other";
  assert.throws(() => m.parseImport(JSON.stringify([w[0], dupe])));
});
