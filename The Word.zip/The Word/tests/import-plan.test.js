const { test } = require("node:test");
const assert = require("node:assert/strict");
const { createImportPlan } = require("../miniprogram/utils/import-plan");
const model = require("../miniprogram/utils/model");
const demo = require("../miniprogram/data/demo");
const existing = () => demo.map(model.validateWord);
const incoming = () =>
  existing().map((w) =>
    Object.assign({}, w, { note: "新版", mastered: true, mistakes: 7 }),
  );

test("逐项覆盖和跳过，普通新词仍添加；决定完成前不修改原数组", () => {
  const original = existing(),
    snapshot = JSON.stringify(original);
  const extra = Object.assign({}, incoming()[0], { id: "new", text: "new" });
  const p = createImportPlan(original, incoming().concat(extra));
  assert.equal(p.next().incoming.text, "ancient");
  assert.throws(() => p.result());
  p.resolve("overwrite");
  assert.equal(p.next().incoming.text, "antique");
  p.resolve("skip");
  p.next();
  p.resolve("overwrite");
  assert.equal(p.next(), null);
  const r = p.result();
  assert.deepEqual(r.counts, { added: 1, overwritten: 2, skipped: 1 });
  assert.equal(r.words[0].mistakes, 7);
  assert.equal(r.words[1].note, original[1].note);
  assert.equal(JSON.stringify(original), snapshot);
});
for (const action of ["overwriteAll", "skipAll"]) {
  test(action + " 自动处理本次剩余冲突，但不影响下一次导入", () => {
    const rows = incoming();
    rows.splice(
      1,
      0,
      Object.assign({}, rows[0], { id: "extra", text: "extra" }),
    );
    const p = createImportPlan(existing(), rows);
    p.next();
    p.resolve(action);
    assert.equal(p.next(), null);
    assert.deepEqual(p.result().counts, {
      added: 1,
      overwritten: action === "overwriteAll" ? 3 : 0,
      skipped: action === "skipAll" ? 3 : 0,
    });
    assert.ok(createImportPlan(existing(), incoming()).next());
  });
}
test("同名不同 ID 覆盖保留本地 ID；同 ID 改名后更新冲突索引", () => {
  const row = incoming()[0];
  row.id = "foreign";
  row.text = "ANCIENT";
  const p = createImportPlan(existing(), [row]);
  assert.equal(p.next().existing.id, "demo_ancient");
  p.resolve("overwrite");
  p.next();
  assert.equal(p.result().words[0].id, "demo_ancient");
  const renamed = incoming()[0];
  renamed.text = "renamed";
  const newOldName = Object.assign({}, incoming()[0], { id: "new_ancient" });
  const q = createImportPlan(existing(), [renamed, newOldName]);
  q.next();
  q.resolve("overwrite");
  assert.equal(q.next(), null);
  assert.equal(q.result().counts.added, 1);
});
test("相同英文属于不同词书且 ID 不同则直接新增；双重身份冲突不误删词", () => {
  const row = Object.assign({}, incoming()[0], {
    list: "另一词书",
    id: "other",
  });
  const p = createImportPlan(existing(), [row]);
  assert.equal(p.next(), null);
  assert.equal(p.result().counts.added, 1);
  const ambiguous = incoming()[0];
  ambiguous.text = "modern";
  assert.throws(
    () => createImportPlan(existing(), [ambiguous]).next(),
    /分别对应两个/,
  );
});
