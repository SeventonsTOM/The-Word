const { test, beforeEach } = require("node:test"),
  assert = require("node:assert/strict");
const clone = (x) => (x === undefined ? x : JSON.parse(JSON.stringify(x)));
let memory = {},
  fail = false;
global.wx = {
  getStorageSync: (k) => clone(memory[k]),
  setStorageSync: (k, v) => {
    if (fail || Buffer.byteLength(JSON.stringify(v)) > 1024 * 1024)
      throw new Error("quota");
    memory[k] = clone(v);
  },
  removeStorageSync: (k) => delete memory[k],
};
const store = require("../miniprogram/utils/store"),
  m = require("../miniprogram/utils/model"),
  demo = require("../miniprogram/data/demo");
beforeEach(() => {
  memory = {};
  fail = false;
  store.initialize();
  store.importWords(demo.map(m.validateWord));
});
const options = {
  lists: [demo[0].list],
  includeMastered: false,
  onlyHighlights: false,
  minLevel: "normal",
  repeatDifficult: true,
  shuffle: false,
  mode: "count",
  amount: 1,
};
const { createImportPlan } = require("../miniprogram/utils/import-plan");
function overwritePlan() {
  const rows = store
    .words()
    .map((w) => Object.assign({}, w, { note: "导入版本" }));
  const plan = createImportPlan(store.words(), rows);
  plan.next();
  plan.resolve("overwriteAll");
  plan.next();
  return plan;
}
test("覆盖导入一次提交，保留历史并结束受影响的当前抽查", () => {
  store.start(m.buildSession(store.words(), options));
  const result = store.commitImport(overwritePlan());
  assert.equal(result.overwritten, 3);
  assert.equal(result.cancelledSession, true);
  assert.equal(store.get(demo[0].id).note, "导入版本");
  assert.equal(store.read().session, null);
  assert.deepEqual(store.read().history, []);
});
test("覆盖提交失败或词库在选择期间变化时保留全部旧数据", () => {
  const plan = overwritePlan(),
    before = store.read();
  fail = true;
  assert.throws(() => store.commitImport(plan), /保存失败/);
  assert.deepEqual(store.read(), before);
  fail = false;
  const w = store.words()[0];
  w.note = "选择期间的修改";
  store.save(w);
  assert.throws(() => store.commitImport(plan), /词库发生了变化/);
  assert.equal(store.get(w.id).note, "选择期间的修改");
});
test("保存编辑与重复词校验，保存失败不损坏旧数据", () => {
  const w = store.words()[0];
  w.note = "edited";
  store.save(w);
  assert.equal(store.get(w.id).note, "edited");
  assert.throws(() => store.save(Object.assign({}, w, { id: "different" })));
  fail = true;
  w.note = "unsaved";
  assert.throws(() => store.save(w));
  assert.equal(store.get(w.id).note, "edited");
});
test("默认单词和短语独立升级，跨轮保留、最高 Stubborn，答对跳过不降级", () => {
  const w = store.words()[0];
  w.mastered = true;
  store.save(w);
  for (const level of ["shaky", "tricky", "stubborn", "stubborn"]) {
    store.start(
      m.buildSession(store.words(), {
        ...options,
        includeMastered: true,
        repeatDifficult: false,
      }),
    );
    const previousPhrase = store.get(w.id).branches[0].phrases[0].level;
    store.answer("wrong");
    assert.equal(store.get(w.id).level, level);
    assert.equal(store.get(w.id).mastered, false);
    assert.equal(store.get(w.id).branches[0].phrases[0].level, previousPhrase);
    store.answer("wrong");
    assert.equal(store.get(w.id).level, level);
    assert.equal(store.get(w.id).branches[0].phrases[0].level, level);
    store.answer("known");
    store.answer("skip");
    assert.equal(store.get(w.id).branches[0].phrases[1].level, "normal");
    assert.equal(store.get(w.id).branches[0].phrases[2].level, "normal");
    while (!store.read().session.completed) store.answer("skip");
    assert.equal(
      store.read().session.queue.length,
      6,
      "本轮升级不能无限追加题目",
    );
  }
  assert.equal(store.get(w.id).mistakes, 4);
  assert.equal(store.get(w.id).branches[0].phrases[0].mistakes, 4);
  store.start(m.buildSession(store.words(), options));
  assert.equal(store.get(w.id).level, "stubborn");
  assert.equal(store.read().session.queue.length, 8);
});

test("升降档开关四种组合分别作用于单词和短语，四档边界与错误次数正确", () => {
  const cases = [
    ["normal", "shaky", "normal"],
    ["shaky", "tricky", "normal"],
    ["tricky", "stubborn", "shaky"],
    ["stubborn", "stubborn", "tricky"],
  ];
  for (const autoUpgrade of [false, true])
    for (const autoDowngrade of [false, true])
      for (const type of ["word", "phrase"])
        for (const [level, up, down] of cases)
          for (const rating of ["wrong", "known", "skip"]) {
            const word = m.validateWord(clone(demo[0]));
            word.level = level;
            word.mistakes = 10;
            word.branches[0].phrases[0].level = level;
            word.branches[0].phrases[0].mistakes = 7;
            store.save(word);
            store.start(
              m.buildSession(store.words(), {
                ...options,
                autoUpgrade,
                autoDowngrade,
                repeatDifficult: false,
              }),
            );
            if (type === "phrase") store.answer("skip");
            store.answer(rating);
            const saved = store.get(word.id);
            const target =
              type === "word" ? saved : saved.branches[0].phrases[0];
            const other =
              type === "word" ? saved.branches[0].phrases[0] : saved;
            const expected =
              rating === "wrong" && autoUpgrade
                ? up
                : rating === "known" && autoDowngrade
                  ? down
                  : level;
            const label = `${type}/${level}/${rating}/升${autoUpgrade}/降${autoDowngrade}`;
            assert.equal(target.level, expected, label);
            assert.equal(
              target.mistakes,
              (type === "word" ? 10 : 7) + (rating === "wrong" ? 1 : 0),
              label,
            );
            assert.equal(other.level, level, label);
            assert.equal(other.mistakes, type === "word" ? 7 : 10, label);
            assert.equal(saved.branches[0].phrases[1].level, "normal", label);
            assert.equal(
              saved.mastered,
              false,
              "降至 Normal 不能自动标为已掌握",
            );
            assert.equal(store.read().session.autoUpgrade, autoUpgrade);
            assert.equal(store.read().session.autoDowngrade, autoDowngrade);
          }
});

test("降档与作答一起保存，失败整体回滚，回看和结束后不重复降档", () => {
  const w = store.words()[0];
  store.setLevel(w.id, "shaky");
  store.start(
    m.buildSession(store.words(), {
      ...options,
      autoUpgrade: true,
      autoDowngrade: true,
      repeatDifficult: true,
    }),
  );
  const before = store.read();
  fail = true;
  assert.throws(() => store.answer("known"), /保存失败/);
  assert.deepEqual(store.read(), before);
  fail = false;
  store.answer("known");
  assert.equal(store.get(w.id).level, "normal");
  const answered = store.read();
  store.previous();
  assert.throws(() => store.answer("known"), /回看/);
  assert.deepEqual(store.words(), answered.words);
  assert.deepEqual(store.read().session.ratings, answered.session.ratings);
  store.forward();
  while (!store.read().session.completed) store.answer("known");
  assert.equal(store.get(w.id).level, "normal");
  assert.deepEqual(
    store.read().session.queue,
    before.session.queue,
    "降档不会删除开局已经安排的加练",
  );
  assert.equal(store.read().history.length, 1);
  const finished = store.read();
  store.answer("known");
  assert.deepEqual(store.read(), finished);
});

test("旧抽查未保存开关时保留答错升档、答对不降档，关闭升档也照常记录答错", () => {
  const word = store.words()[0];
  store.setLevel(word.id, "tricky");
  store.setLevel(word.id, "tricky", word.branches[0].phrases[0].id);
  const legacy = m.buildSession(store.words(), {
    ...options,
    repeatDifficult: false,
  });
  delete legacy.autoUpgrade;
  delete legacy.autoDowngrade;
  store.start(legacy);
  store.answer("wrong");
  store.answer("known");
  assert.equal(store.get(word.id).level, "stubborn");
  assert.equal(store.get(word.id).branches[0].phrases[0].level, "tricky");
  store.flag(word.id, "mastered");
  store.start(
    m.buildSession(store.words(), {
      ...options,
      autoUpgrade: false,
      autoDowngrade: false,
      includeMastered: true,
    }),
  );
  store.answer("wrong");
  assert.equal(store.get(word.id).level, "normal");
  assert.equal(store.get(word.id).mistakes, 2);
  assert.equal(store.get(word.id).mastered, false);
});

test("短语手动分级互不影响，历史高错误短语调回 Normal 后只升一级", () => {
  const w = store.words()[0],
    p = w.branches[0].phrases[0];
  p.mistakes = 12;
  store.save(w);
  for (const level of ["stubborn", "tricky", "shaky", "normal"]) {
    store.setLevel(w.id, level, p.id);
    assert.equal(store.get(w.id).branches[0].phrases[0].level, level);
    assert.equal(store.get(w.id).level, "normal");
    assert.equal(store.get(w.id).branches[0].phrases[1].level, "normal");
  }
  store.start(m.buildSession(store.words(), options));
  store.answer("skip");
  store.answer("wrong");
  const saved = store.get(w.id);
  assert.equal(saved.level, "normal");
  assert.equal(saved.mistakes, 0);
  assert.equal(saved.branches[0].phrases[0].level, "shaky");
  assert.equal(saved.branches[0].phrases[0].mistakes, 13);
  assert.throws(
    () => store.setLevel(w.id, "tricky", "missing"),
    /短语已不存在/,
  );
});

test("上一题和下一题仅回看，暂停可恢复位置，不重复计错或写入历史", () => {
  store.start(m.buildSession(store.words(), options));
  store.previous();
  assert.equal(store.read().session.reviewIndex, undefined);
  store.answer("wrong");
  store.answer("skip");
  const before = store.read();
  store.previous();
  assert.equal(store.read().session.reviewIndex, 1);
  store.previous();
  store.previous();
  assert.equal(store.read().session.reviewIndex, 0);
  assert.throws(() => store.answer("wrong"), /回看/);
  assert.deepEqual(store.words(), before.words);
  assert.deepEqual(store.read().session.ratings, before.session.ratings);
  assert.deepEqual(store.read().history, []);
  fail = true;
  assert.throws(() => store.forward(), /保存失败/);
  assert.equal(store.read().session.reviewIndex, 0);
  fail = false;
  store.forward();
  store.forward();
  assert.equal(store.read().session.reviewIndex, undefined);
  assert.equal(store.read().session.index, 2);
  while (!store.read().session.completed) store.answer("known");
  assert.equal(store.read().history.length, 1);
  assert.equal(store.read().history[0].known, 4);
  assert.equal(store.get(before.words[0].id).mistakes, 1);
});
test("整轮结束只记录一次历史，跳过不算错误", () => {
  store.start(m.buildSession(store.words(), options));
  store.answer("wrong");
  store.answer("skip");
  for (let i = 0; i < 4; i++) store.answer("known");
  const d = store.read();
  assert.equal(d.session.completed, true);
  assert.equal(d.history.length, 1);
  assert.equal(d.history[0].known, 4);
  assert.equal(store.get(d.words[0].id).mistakes, 1);
  store.answer("wrong");
  assert.equal(store.read().history.length, 1);
});
test("可手动四选一，标为掌握回 Normal，调低后按当前等级升级", () => {
  const id = store.words()[0].id;
  for (const level of ["normal", "shaky", "tricky", "stubborn"]) {
    store.setLevel(id, level);
    assert.equal(store.get(id).level, level);
  }
  store.flag(id, "mastered");
  assert.equal(store.get(id).mastered, true);
  assert.equal(store.get(id).level, "normal");
  store.setLevel(id, "shaky");
  assert.equal(store.get(id).mastered, false);
  const word = store.get(id);
  word.mistakes = 20;
  store.save(word);
  store.setLevel(id, "normal");
  store.start(m.buildSession(store.words(), options));
  store.answer("wrong");
  assert.equal(store.get(id).level, "shaky");
  assert.equal(store.get(id).mistakes, 21);
  assert.throws(() => store.setLevel(id, "unknown"), /分级/);
  fail = true;
  assert.throws(() => store.setLevel(id, "stubborn"), /保存失败/);
  assert.equal(store.get(id).level, "shaky");
});

test("旧本地缓存转换后保留词条和抽查进度，保存后不重复按旧错误次数分级", () => {
  const old = store.read();
  old.words.forEach((w, i) => {
    delete w.level;
    w.bomb = i === 0;
    w.mistakes = i === 0 ? 4 : i;
  });
  old.session = m.buildSession(old.words, options);
  memory["wordbook.v1"] = clone(old);
  const migrated = store.read();
  assert.deepEqual(
    migrated.words.map((w) => w.level),
    ["stubborn", "shaky", "tricky"],
  );
  assert.deepEqual(migrated.session, old.session);
  assert.ok(migrated.words.every((w) => !Object.hasOwn(w, "bomb")));
  store.setLevel(old.words[0].id, "normal");
  assert.equal(store.get(old.words[0].id).level, "normal");
  assert.equal(store.get(old.words[0].id).mistakes, 4);
  store.answer("wrong");
  assert.equal(store.get(old.words[0].id).level, "shaky");
});
test("词书重命名同步更新全部词条，并阻止空名和同名合并", () => {
  const second = m.validateWord(demo[0]);
  second.id = "second_list_word";
  second.text = "second";
  second.list = "第二本词书";
  store.importWords([second]);
  const result = store.renameList("示例词表 · 结构演示", " 考研词汇 ");
  assert.deepEqual(result, { name: "考研词汇", count: 3 });
  assert.equal(store.words().filter((w) => w.list === "考研词汇").length, 3);
  assert.throws(() => store.renameList("考研词汇", ""));
  assert.throws(() => store.renameList("考研词汇", "第二本词书"));
});
test("删除整本词书只移除其词条，并结束引用这些词条的当前抽查", () => {
  const second = m.validateWord(demo[0]);
  second.id = "second_list_word";
  second.text = "second";
  second.list = "第二本词书";
  store.importWords([second]);
  store.start(m.buildSession(store.words(), options));
  const result = store.removeList("示例词表 · 结构演示");
  assert.deepEqual(result, { count: 3, cancelledSession: true });
  assert.deepEqual(
    store.words().map((w) => w.text),
    ["second"],
  );
  assert.equal(store.read().session, null);
  assert.throws(() => store.removeList("不存在的词书"));
});
test("合并导入跳过重复且保留本机编辑，删除词条不破坏当前题快照", () => {
  const w = store.words()[0];
  w.note = "本机修改";
  store.save(w);
  const r = store.importWords(demo.map(m.validateWord));
  assert.deepEqual(r, { added: 0, skipped: 3 });
  assert.equal(store.get(w.id).note, "本机修改");
  store.start(m.buildSession(store.words(), options));
  store.remove(w.id);
  assert.equal(store.read().session.queue[0].text, "ancient");
  store.answer("wrong");
  assert.equal(store.read().session.index, 1);
});
test("作答存储失败时题号与错题计数一起回滚", () => {
  store.start(m.buildSession(store.words(), options));
  fail = true;
  assert.throws(() => store.answer("wrong"));
  assert.equal(store.read().session.index, 0);
  assert.equal(store.words()[0].mistakes, 0);
  assert.equal(store.words()[0].level, "normal");
});
test("超过单条缓存上限的词书可分块保存，替换后清理旧块", () => {
  const incoming = [];
  for (let i = 0; i < 600; i++) {
    const w = m.validateWord(demo[0]);
    w.id = "bulk_" + i;
    w.text = "word" + i;
    w.note = "记".repeat(1000);
    incoming.push(w);
  }
  store.importWords(incoming);
  assert.equal(store.words().length, 603);
  assert.ok(memory["wordbook.v1"].chunks.length > 1);
  const old = memory["wordbook.v1"].chunks.slice();
  const w = store.words()[0];
  w.note = "new";
  store.save(w);
  assert.ok(old.every((k) => memory[k] === undefined));
  assert.equal(store.words().length, 603);
});
