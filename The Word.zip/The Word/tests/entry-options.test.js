const { test } = require("node:test");
const assert = require("node:assert/strict");
const {
  normalizePage,
  displayPage,
} = require("../miniprogram/utils/page-number");
const options = require("../miniprogram/utils/entry-options");
const model = require("../miniprogram/utils/model");
const demo = require("../miniprogram/data/demo");

test("数字、汉语数字、P/p 前缀及旧页码统一为 P+阿拉伯数字", () => {
  for (const raw of [
    "426",
    426,
    "四百二十六",
    "四二六",
    "P426",
    "p426",
    " p 00426 ",
    "Ｐ４２６",
    "第426页",
    "肆佰贰拾陆",
  ])
    assert.equal(normalizePage(raw), "P426", String(raw));
  for (const [raw, expected] of [
    ["十", "P10"],
    ["十二", "P12"],
    ["二十", "P20"],
    ["一百零二", "P102"],
    ["两千零六", "P2006"],
    ["一万零三", "P10003"],
    ["二〇二六", "P2026"],
  ])
    assert.equal(normalizePage(raw), expected);
  for (const raw of ["", " ", null, undefined])
    assert.equal(normalizePage(raw), "");
  assert.equal(normalizePage(normalizePage("四百二十六")), "P426");
  assert.equal(displayPage("426"), "P426");
});
test("非法页码不能误保存为其他数字，已有不可识别文本仅在读取时保留", () => {
  for (const raw of [
    "P",
    "PP426",
    "零",
    0,
    -3,
    "12.5",
    "十十",
    "百",
    "四百二三",
    "1-3",
    "abc",
    {},
    "9007199254740992",
  ])
    assert.throws(() => normalizePage(raw), /页码/);
  assert.equal(displayPage("附录 A"), "附录 A");
});
test("主词条、关联词与 JSON 导入同时规范页码，不清除兼容字段", () => {
  const w = Object.assign({}, demo[0], {
    page: "四百二十六",
    related: [{ text: "modern", page: "p0020" }],
  });
  const result = model.validateWord(w);
  assert.equal(result.page, "P426");
  assert.equal(result.related[0].page, "P20");
  assert.equal(result.mnemonic, w.mnemonic);
  assert.equal(model.parseImport(JSON.stringify([w]))[0].page, "P426");
  assert.throws(() =>
    model.validateWord(
      Object.assign({}, w, { related: [{ text: "modern", page: "-1" }] }),
    ),
  );
});
test("词表按尾部数字排序，词根按英文字母排序，已有选项去重", () => {
  assert.deepEqual(
    ["Word List 10", "Word List 02", "Word List 1", "未编号"].sort(
      options.compareLists,
    ),
    ["Word List 1", "Word List 02", "Word List 10", "未编号"],
  );
  assert.deepEqual(
    ["zoo · 动物", "Bio · 生命", "-anci · 古老"].sort(options.compareRoots),
    ["-anci · 古老", "Bio · 生命", "zoo · 动物"],
  );
  assert.deepEqual(
    options.names(
      [{ list: "List 2" }, { list: "List 1" }, { list: "List 2" }],
      "list",
    ),
    ["List 1", "List 2"],
  );
});
test("词性列表按显示英文名称排序，覆盖主要词类、动词细分及已有词性", () => {
  const poses = options.posOptions([{ pos: "custom-pos" }]);
  assert.deepEqual(
    poses.map((p) => p.value),
    poses.map((p) => p.value).sort(options.alphabetic),
  );
  for (const value of [
    "a.",
    "adj.",
    "ad.",
    "adv.",
    "art.",
    "aux.v.",
    "conj.",
    "det.",
    "int.",
    "interj.",
    "modal v.",
    "n.",
    "num.",
    "part.",
    "prep.",
    "pron.",
    "v.",
    "vi.",
    "vt.",
    "v.link.",
    "custom-pos",
  ])
    assert.ok(
      poses.some((p) => p.value === value),
      value,
    );
});
