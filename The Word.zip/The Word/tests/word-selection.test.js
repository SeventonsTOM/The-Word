const { test } = require("node:test");
const assert = require("node:assert/strict");
const selection = require("../miniprogram/utils/word-selection");
const fixture = [
  ["critic", "书一", "crit"],
  ["critical", "书一", "crit"],
  ["other", "书二", "other"],
  ["crown", "书一", "crown"],
  ["core", "书一", "core"],
  ["after", "书一", "a"],
].map(([text, list, root]) => ({
  id: text,
  text,
  list,
  root,
  page: "P26",
  branches: [{ pos: "n.", meanings: ["示例汉义"] }],
}));

test("本书按导入顺序编号，区间跨词根、包含两端且不跨词书", () => {
  const rows = selection.bookRows(fixture, "书一");
  assert.deepEqual(
    rows.map((w) => [w.number, w.text]),
    [
      [1, "critic"],
      [2, "critical"],
      [3, "crown"],
      [4, "core"],
      [5, "after"],
    ],
  );
  assert.deepEqual(selection.rangeIds(rows, "critic", "core"), [
    "critic",
    "critical",
    "crown",
    "core",
  ]);
  assert.deepEqual(
    selection.rangeIds(rows, "core", "critic"),
    selection.rangeIds(rows, "critic", "core"),
  );
  assert.deepEqual(selection.rangeIds(rows, "core", "core"), ["core"]);
  assert.throws(() => selection.rangeIds(rows, "critic", "other"), /当前词书/);
  assert.throws(() => selection.rangeIds(rows, "", "core"), /起点和终点/);
});

test("重叠选择去重并合并，取消单词会拆段，删除词条后按 ID 保持选择", () => {
  const rows = selection.bookRows(fixture, "书一");
  const ids = new Set(selection.rangeIds(rows, "critic", "crown"));
  selection.rangeIds(rows, "critical", "core").forEach((id) => ids.add(id));
  let runs = selection.segments(rows, ids);
  assert.equal(ids.size, 4);
  assert.equal(runs.length, 1);
  assert.equal(runs[0].startText, "critic");
  assert.equal(runs[0].endText, "core");
  ids.delete("critical");
  runs = selection.segments(rows, ids);
  assert.deepEqual(
    runs.map((r) => r.count),
    [1, 2],
  );
  const changed = selection.bookRows(
    fixture.filter((w) => w.id !== "crown"),
    "书一",
  );
  runs = selection.segments(changed, ids);
  assert.deepEqual(
    runs.map((r) => [r.startNumber, r.startText]),
    [
      [1, "critic"],
      [3, "core"],
    ],
  );
  assert.ok(!runs.some((r) => r.endText === "after"));
});

test("起止定位和逐个选择支持英文、汉义、页码与本书序号搜索", () => {
  const rows = selection.bookRows(fixture, "书一");
  assert.deepEqual(
    selection.searchRows(rows, " CRIT ").map((w) => w.text),
    ["critic", "critical"],
  );
  assert.deepEqual(
    selection.searchRows(rows, "#4").map((w) => w.text),
    ["core"],
  );
  assert.deepEqual(
    selection.searchRows(rows, "4").map((w) => w.text),
    ["core"],
  );
  assert.equal(selection.searchRows(rows, "汉义").length, 5);
  assert.equal(selection.searchRows(rows, "p26").length, 5);
  assert.equal(selection.searchRows(rows, "missing").length, 0);
  assert.equal(selection.searchRows(rows, "").length, 5);
});
