const { test, beforeEach } = require("node:test"),
  assert = require("node:assert/strict"),
  path = require("node:path");
let memory = {},
  app = {},
  navigation = [];
const clone = (x) => (x === undefined ? x : JSON.parse(JSON.stringify(x)));
global.wx = {
  getStorageSync: (k) => clone(memory[k]),
  setStorageSync: (k, v) => (memory[k] = clone(v)),
  removeStorageSync: (k) => delete memory[k],
  showModal: (o) => {
    if (o.success) o.success({ confirm: true });
  },
  showToast: () => {},
  navigateTo: (o) => navigation.push(o.url),
  switchTab: (o) => navigation.push(o.url),
  navigateBack: () => navigation.push("back"),
  redirectTo: (o) => navigation.push(o.url),
  createSelectorQuery: () => ({
    in() {
      return this;
    },
    selectAll() {
      return this;
    },
    boundingClientRect(fn) {
      this.fn = fn;
      return this;
    },
    exec() {
      this.fn(
        [0, 1, 2].map((i) => ({
          top: i * 50,
          bottom: (i + 1) * 50,
          left: 0,
          right: 300,
        })),
      );
    },
  }),
};
global.getApp = () => app;
function page(name) {
  const file = path.resolve(
    __dirname,
    "../miniprogram/pages",
    name,
    name + ".js",
  );
  delete require.cache[file];
  let config;
  global.Page = (p) => (config = p);
  require(file);
  const p = Object.assign({}, config, { data: clone(config.data) });
  p.setData = (updates) => {
    for (const [key, val] of Object.entries(updates)) {
      const parts = key.replace(/\[(\d+)\]/g, ".$1").split(".");
      let target = p.data;
      for (let i = 0; i < parts.length - 1; i++) target = target[parts[i]];
      target[parts[parts.length - 1]] = clone(val);
    }
  };
  return p;
}
function event(dataset, value) {
  return { currentTarget: { dataset }, detail: { value } };
}
function selectionFixture() {
  store.importWords(
    [
      ["critic", "Word List 1", "crit"],
      ["critical", "Word List 1", "crit"],
      ["foreign", "Word List 2", "other"],
      ["crown", "Word List 1", "crown"],
      ["core", "Word List 1", "core"],
      ["gap", "Word List 1", "gap"],
      ["last", "Word List 1", "last"],
    ].map(([text, list, root]) =>
      m.validateWord({
        ...m.blankWord(),
        id: text,
        text,
        list,
        root,
        page: "P26",
        branches: [
          {
            id: "branch-" + text,
            pos: "n.",
            meanings: ["测试汉义"],
            highlight: false,
            phrases: [],
          },
        ],
      }),
    ),
  );
  const s = page("setup");
  s.onLoad();
  s.onShow();
  s.chooseSelectionMode(event({ mode: "custom" }));
  s.flag(event({ key: "shuffle" }, false));
  return s;
}
function addSelectedRange(s, start, end) {
  s.openPicker(event({ kind: "start" }));
  s.pickWord(event({ id: start }));
  s.pickWord(event({ id: end }));
  s.addRange();
}
function selectSingleWord(s, id) {
  s.chooseSelectionMode(event({ mode: "custom" }));
  s.openPicker(event({ kind: "words" }));
  s.pickWord(event({ id }));
  s.closePicker();
}
const store = require("../miniprogram/utils/store"),
  m = require("../miniprogram/utils/model");
beforeEach(() => {
  memory = {};
  app = {};
  navigation = [];
  store.initialize();
});
test("从空首页载入示例，四级目录展开并点击单词进入详情", () => {
  const h = page("home");
  h.onShow();
  assert.equal(h.data.total, 0);
  h.demo();
  assert.equal(h.data.total, 3);
  const l = page("library");
  l.onShow();
  assert.equal(l.data.groups[0].roots.length, 2);
  const key = l.data.groups[0].roots[0].words[0].key;
  assert.equal(l.data.groups[0].roots[0].words[0].expanded, true);
  l.toggle(event({ key }));
  assert.equal(l.data.groups[0].roots[0].words[0].expanded, false);
  l.toggle(event({ key }));
  assert.equal(l.data.groups[0].roots[0].words[0].expanded, true);
  l.open(event({ id: "demo_ancient" }));
  assert.equal(navigation.at(-1), "/pages/detail/detail?id=demo_ancient");
  l.search(event({}, "古橡树"));
  assert.equal(l.data.count, 1);
});
test("目录按词表数字/词根字母排序，同名词根的展开状态相互独立，筛选后管理仍使用整本数量", () => {
  page("home").demo();
  const source = store.get("demo_ancient");
  for (const [id, list, root] of [
    ["ten", "Word List 10", "anci"],
    ["two-z", "Word List 2", "zoo"],
    ["two-a", "Word List 2", "anci"],
  ])
    store.save(Object.assign({}, source, { id, text: id, list, root }));
  const l = page("library");
  l.onShow();
  assert.deepEqual(
    l.data.groups.slice(0, 2).map((g) => g.name),
    ["Word List 2", "Word List 10"],
  );
  assert.deepEqual(
    l.data.groups[0].roots.map((r) => r.name),
    ["anci", "zoo"],
  );
  const g = l.data.groups[0],
    r = g.roots[0];
  l.toggle(event({ key: r.key }));
  assert.equal(l.data.groups[0].roots[0].expanded, false);
  assert.equal(l.data.groups[1].roots[0].expanded, true);
  l.toggle(event({ key: g.key }));
  assert.equal(l.data.groups[0].expanded, false);
  l.search(event({}, "anci"));
  assert.equal(l.data.groups[0].expanded, true);
  assert.equal(l.data.groups[0].roots[0].expanded, true);
  l.search(event({}, "zoo"));
  assert.equal(l.data.groups[0].count, 1);
  l.manage(event({ name: "Word List 2" }));
  assert.equal(l.data.managingCount, 2);
});
test("词书管理面板可重命名并经确认删除整本词书", () => {
  const h = page("home");
  h.demo();
  const l = page("library");
  l.onShow();
  l.manage(event({ name: "示例词表 · 结构演示" }));
  assert.equal(l.data.managingCount, 3);
  l.listNameInput(event({}, "我的考研词书"));
  l.renameList();
  assert.ok(store.words().every((w) => w.list === "我的考研词书"));
  l.manage(event({ name: "我的考研词书" }));
  l.deleteList();
  assert.equal(store.words().length, 0);
  assert.equal(l.data.managing, false);
});
test("JSON 导入弹出重复提示，逐项覆盖/跳过及全部操作生效", () => {
  page("home").demo();
  const p = page("backup");
  const rows = store
    .words()
    .map((w) => Object.assign({}, w, { note: "新内容" }));
  p.preview(JSON.stringify(rows));
  assert.equal(p.data.conflict.incoming.text, "ancient");
  p.resolveConflict(event({ action: "overwrite" }));
  assert.equal(p.data.conflict.incoming.text, "antique");
  assert.notEqual(store.get("demo_ancient").note, "新内容");
  p.resolveConflict(event({ action: "skip" }));
  assert.equal(p.data.conflict.incoming.text, "modern");
  p.resolveConflict(event({ action: "skipAll" }));
  assert.equal(p.data.conflict, null);
  assert.equal(store.get("demo_ancient").note, "新内容");
  assert.notEqual(store.get("demo_antique").note, "新内容");
  assert.match(p.data.status, /覆盖 1 个，跳过 2 个/);
  p.preview(JSON.stringify(rows));
  assert.ok(p.data.conflict);
  p.resolveConflict(event({ action: "overwriteAll" }));
  assert.ok(store.words().every((w) => w.note === "新内容"));
});
test("取消或退出冲突选择不保存已选覆盖与新词，下次导入重新询问", () => {
  page("home").demo();
  const before = store.words(),
    p = page("backup");
  const rows = before.map((w) => Object.assign({}, w, { note: "新内容" }));
  rows.unshift(Object.assign({}, rows[0], { id: "new", text: "new" }));
  p.preview(JSON.stringify(rows));
  p.resolveConflict(event({ action: "overwrite" }));
  p.cancelImport();
  assert.deepEqual(store.words(), before);
  p.preview(JSON.stringify(rows));
  assert.equal(p.data.conflict.incoming.text, "ancient");
  p.onUnload();
  assert.deepEqual(store.words(), before);
});
test("表单录入重复词性、多个汉义与短语，保存后详情关联弹窗可打开", () => {
  const h = page("home");
  h.demo();
  const e = page("edit");
  e.onLoad();
  e.chooseList(event({}, 0));
  e.field(event({ key: "text" }, "example"));
  e.choosePos(
    event(
      { branch: 0 },
      e.data.posOptions.findIndex((p) => p.value === "n."),
    ),
  );
  e.field(event({ branch: 0, key: "meaningText" }, "例子；榜样"));
  e.addPhrase(event({ branch: 0 }));
  e.field(event({ branch: 0, phrase: 0, key: "text" }, "for example"));
  e.field(event({ branch: 0, phrase: 0, key: "meaning" }, "例如"));
  e.addRelated();
  e.field(event({ related: 0, key: "text" }, "ancient"));
  const id = e.data.word.id;
  e.save();
  assert.equal(store.get(id).branches[0].meanings.length, 2);
  assert.equal(store.get(id).branches[0].phrases.length, 1);
  const d = page("detail");
  d.onLoad({ id });
  d.onShow();
  d.related(event({ text: "ancient" }));
  assert.equal(d.data.relatedWord.text, "ancient");
  d.close();
  assert.equal(d.data.relatedWord, null);
});
test("录入选择栏新建词表/词根、搜索选择及页码保存完整流程", () => {
  page("home").demo();
  const e = page("edit");
  e.onLoad();
  e.chooseList(event({}, e.data.listRange.length - 1));
  e.nameInput(event({}, "Word List 02"));
  e.confirmName();
  assert.equal(e.data.word.list, "Word List 02");
  e.openRoots();
  e.rootSearch(event({}, "ANCI"));
  assert.deepEqual(e.data.filteredRoots, ["anci · 古老"]);
  e.rootSearch(event({}, "古老"));
  assert.deepEqual(e.data.filteredRoots, ["anci · 古老"]);
  e.rootSearch(event({}, "bio · 生命"));
  e.startCreateRoot();
  e.confirmName();
  assert.equal(e.data.word.root, "bio · 生命");
  e.field(event({ key: "text" }, "biology"));
  e.choosePos(
    event(
      { branch: 0 },
      e.data.posOptions.findIndex((p) => p.value === "n."),
    ),
  );
  e.field(event({ branch: 0, key: "meaningText" }, "生物学"));
  e.field(event({ key: "page" }, "四百二十六"));
  e.addRelated();
  e.field(event({ related: 0, key: "text" }, "ancient"));
  e.field(event({ related: 0, key: "page" }, "p0020"));
  const id = e.data.word.id;
  e.save();
  const saved = store.get(id);
  assert.equal(saved.page, "P426");
  assert.equal(saved.related[0].page, "P20");
  const next = page("edit");
  next.onLoad();
  assert.ok(next.data.listOptions.includes("Word List 02"));
  assert.ok(next.data.rootOptions.includes("bio · 生命"));
  const d = page("detail");
  d.onLoad({ id });
  d.onShow();
  assert.equal(d.data.word.page, "P426");
});

test("录入确认键按当前页面顺序跳转，含新增/删除后的分支、短语和关联词", () => {
  const e = page("edit");
  e.onLoad();
  e.addPhrase(event({ branch: 0 }));
  e.addBranch();
  e.addPhrase(event({ branch: 1 }));
  e.addRelated();
  const b0 = e.data.word.branches[0],
    b1 = e.data.word.branches[1];
  const steps = [
    [{ input: "text", key: "text" }, "ancient", "page"],
    [{ input: "page", key: "page" }, "二十六", "meaning-" + b0.id],
    [
      { input: "meaning-" + b0.id, branch: 0, key: "meaningText" },
      "古代的\n古老的",
      "phrase-" + b0.phrases[0].id + "-text",
    ],
    [
      {
        input: "phrase-" + b0.phrases[0].id + "-text",
        branch: 0,
        phrase: 0,
        key: "text",
      },
      "in ancient times",
      "phrase-" + b0.phrases[0].id + "-meaning",
    ],
    [
      {
        input: "phrase-" + b0.phrases[0].id + "-meaning",
        branch: 0,
        phrase: 0,
        key: "meaning",
      },
      "在古代",
      "meaning-" + b1.id,
    ],
  ];
  for (const [dataset, value, next] of steps) {
    e.inputFocus(event(dataset));
    e.inputConfirm(event(dataset, value));
    e.inputBlur(event(dataset, value));
    assert.equal(e.data.focusedInput, next, "迟到的 blur 不应清掉下一项焦点");
  }
  assert.equal(e.data.word.text, "ancient");
  assert.equal(e.data.word.branches[0].meaningText, "古代的\n古老的");
  assert.equal(
    memory["wordbook.draft.v1"].word.branches[0].phrases[0].meaning,
    "在古代",
  );
  e.removePhrase(event({ branch: 1, phrase: 0 }));
  e.inputConfirm(
    event({ input: "meaning-" + b1.id, branch: 1, key: "meaningText" }, "古人"),
  );
  assert.equal(e.data.focusedInput, "related-0-text");
  e.inputConfirm(
    event({ input: "related-0-text", related: 0, key: "text" }, "modern"),
  );
  assert.equal(e.data.focusedInput, "related-0-page");
  e.inputConfirm(
    event({ input: "related-0-page", related: 0, key: "page" }, "p8"),
  );
  assert.equal(e.data.focusedInput, "note");
  e.inputConfirm(event({ input: "note", key: "note" }, "第一行\n第二行"));
  assert.equal(e.data.focusedInput, "");
  assert.equal(e.data.word.note, "第一行\n第二行");
  assert.equal(store.words().length, 0, "最后一项不能自动保存或跳到详情");
  assert.deepEqual(navigation, []);
  e.removeRelated(event({ related: 0 }));
  e.removeBranch(event({ branch: 1 }));
  assert.equal(
    e.inputOrder().at(-2),
    "phrase-" + b0.phrases[0].id + "-meaning",
  );
});

test("多行输入和粘贴保留换行；打开选择面板后不再响应主表单确认事件", () => {
  const e = page("edit");
  e.onLoad();
  const dataset = {
    input: "meaning-" + e.data.word.branches[0].id,
    branch: 0,
    key: "meaningText",
  };
  e.inputFocus(event(dataset));
  e.field(event(dataset, "词义一\n词义二\n"));
  assert.equal(e.data.focusedInput, dataset.input);
  assert.equal(e.data.word.branches[0].meaningText, "词义一\n词义二\n");
  e.openRoots();
  assert.equal(e.data.focusedInput, "");
  e.inputConfirm(event(dataset, "迟到的旧值"));
  assert.equal(e.data.focusedInput, "");
  assert.equal(e.data.word.branches[0].meaningText, "词义一\n词义二\n");
});
test("取消新建不改变原选项，重名复用，旧草稿和词条的记法可在备注编辑", () => {
  page("home").demo();
  const e = page("edit");
  e.onLoad();
  assert.deepEqual(e.data.listRange, e.data.listOptions.concat("＋ 新建词表"));
  e.chooseList(event({}, 0));
  assert.equal(e.data.word.list, e.data.listOptions[0]);
  const original = e.data.word.list;
  e.chooseList(event({}, e.data.listRange.length - 1));
  e.nameInput(event({}, "放弃新建"));
  e.closeSelector();
  assert.equal(e.data.word.list, original);
  e.openRoots();
  e.rootSearch(event({}, "anci · 古老"));
  e.startCreateRoot();
  e.confirmName();
  assert.equal(e.data.rootOptions.filter((r) => r === "anci · 古老").length, 1);
  e.field(event({ branch: 0, key: "meaningText" }, "还没保存的汉义"));
  e.persist();
  const restored = page("edit");
  restored.onLoad();
  assert.equal(restored.data.word.branches[0].meaningText, "还没保存的汉义");
  const ancient = store.get("demo_ancient");
  app.editWordId = ancient.id;
  restored.onShow();
  assert.ok(restored.data.word.note.includes(ancient.mnemonic));
  assert.equal(restored.data.word.mnemonic, "");
  assert.equal(restored.data.word.branches[0].pos, "a.");
  assert.ok(restored.data.word.branches[0].posLabel);
});
test("长按滑动连选覆盖跨过的词表，松手后的点击不误翻转", () => {
  const p = page("setup");
  p.words = [];
  p.setData({
    lists: [0, 1, 2].map((i) => ({
      name: "list" + i,
      selected: false,
      count: 0,
    })),
  });
  p.longpress(event({ index: 0 }));
  p.touchmove({ touches: [{ clientX: 20, clientY: 125 }] });
  assert.ok(p.data.lists.every((l) => l.selected));
  p.touchend();
  p.toggle(event({ index: 0 }));
  assert.ok(p.data.lists[0].selected);
});
test("自选连续区间跨词根，支持搜索首尾、多段合并和逐词调整，实际出题严格匹配", () => {
  const s = selectionFixture();
  assert.equal(s.data.selectedCount, 0);
  s.start();
  assert.equal(store.read().session, null);
  assert.deepEqual(navigation, []);
  s.openPicker(event({ kind: "start" }));
  s.pickerSearch(event({}, "crit"));
  assert.deepEqual(
    s.data.pickerRows.map((r) => r.text),
    ["critic", "critical"],
  );
  s.pickWord(event({ id: "critic" }));
  assert.equal(s.data.pickerKind, "end");
  assert.equal(s.data.pickerOpen, true);
  assert.equal(s.data.rangeStartLabel, "#1 critic");
  s.pickerSearch(event({}, "core"));
  s.pickWord(event({ id: "core" }));
  assert.equal(s.data.pickerOpen, false);
  assert.equal(s.data.rangeCount, 4);
  assert.equal(s.data.pickedCount, 0, "首尾选择须通过添加这一段提交");
  s.addRange();
  assert.equal(s.data.pickedCount, 4);
  assert.equal(s.data.selectedCount, 4);
  assert.equal(s.data.segmentCount, 1);
  addSelectedRange(s, "core", "critical");
  assert.equal(s.data.pickedCount, 4, "反向和重叠范围不能重复选词");
  addSelectedRange(s, "last", "last");
  selectSingleWord(s, "critical");
  assert.deepEqual(
    s.data.segments.map((r) => r.count),
    [1, 2, 1],
  );
  assert.equal(s.data.selectedCount, 4);
  s.start();
  assert.deepEqual(
    store.read().session.queue.map((q) => q.text),
    ["critic", "crown", "core", "last"],
  );
  assert.equal(store.read().session.wordCount, 4);
  s.removeSegment(event({ id: "crown" }));
  assert.deepEqual(s.opts().wordIds, ["critic", "last"]);
  s.clearSelection();
  assert.equal(s.data.selectedCount, 0);
  s.chooseSelectionMode(event({ mode: "all" }));
  assert.equal(
    s.data.selectedCount,
    7,
    "全部符合条件模式仍可使用原有多词表范围",
  );
});

test("切换词书分别保留选择，范围与批量搜索不混入其他词书，取消词表后同步范围", () => {
  const s = selectionFixture();
  addSelectedRange(s, "critic", "core");
  s.chooseBook(event({}, 1));
  assert.equal(s.data.bookName, "Word List 2");
  assert.equal(s.data.pickedCount, 0);
  assert.equal(s.data.rangeStartId, "");
  s.openPicker(event({ kind: "words" }));
  s.pickWord(event({ id: "critic" }));
  assert.equal(s.data.pickedCount, 0, "其他词书 ID 无法在本书勾选");
  s.selectSearchResults(event({ action: "add" }));
  assert.deepEqual(s.opts().wordIds, ["foreign"]);
  s.start();
  assert.deepEqual(
    store.read().session.queue.map((q) => q.text),
    ["foreign"],
  );
  s.chooseBook(event({}, 0));
  assert.equal(s.data.pickedCount, 4);
  assert.deepEqual(s.opts().lists, ["Word List 1"]);
  assert.ok(!s.opts().wordIds.includes("foreign"));
  s.toggle(event({ index: 0 }));
  assert.equal(s.data.bookName, "Word List 2");
  assert.deepEqual(s.opts().wordIds, ["foreign"]);
  s.toggle(event({ index: 1 }));
  assert.equal(s.data.bookName, "");
  assert.equal(s.data.pickerOpen, false);
  assert.equal(s.data.selectedCount, 0);
  assert.deepEqual(s.opts().lists, []);
});

test("自选编号不因筛选变化，数量与单词/短语难度独立筛选一致", () => {
  const s = selectionFixture();
  const w = store.get("core");
  w.branches[0].highlight = true;
  w.branches[0].phrases.push({
    id: "core-phrase",
    text: "at the core",
    meaning: "在核心",
    highlight: true,
    level: "tricky",
  });
  store.save(w);
  s.onShow();
  addSelectedRange(s, "critic", "core");
  s.chooseLevel(event({}, "tricky"));
  s.flag(event({ key: "onlyHighlights" }, true));
  assert.equal(s.data.pickedCount, 4);
  assert.equal(s.data.selectedCount, 1);
  assert.equal(s.data.excludedCount, 3);
  s.openPicker(event({ kind: "words" }));
  assert.deepEqual(
    s.data.pickerRows.map((r) => r.number),
    [1, 2, 3, 4, 5, 6],
  );
  assert.deepEqual(
    s.data.pickerRows.filter((r) => r.eligible).map((r) => r.text),
    ["core"],
  );
  s.closePicker();
  s.start();
  assert.ok(
    store
      .read()
      .session.queue.every(
        (q) => q.type === "phrase" && q.phraseId === "core-phrase",
      ),
  );
  assert.equal(
    store.read().session.queue.length,
    2,
    "只有符合条件的已选短语进入队尾加练",
  );
  store.flag("core", "mastered", true);
  s.onShow();
  assert.equal(s.data.selectedCount, 0);
  assert.equal(s.data.excludedCount, 4);
  s.flag(event({ key: "includeMastered" }, true));
  assert.equal(s.data.selectedCount, 1);
  s.chooseLevel(event({}, "normal"));
  s.flag(event({ key: "onlyHighlights" }, false));
  assert.equal(s.data.selectedCount, 4);
});

test("设置仅重点后的数量与实际抽查一致，重点单词的非重点短语不会出现", () => {
  page("home").demo();
  const markedPhraseOnly = store.get("demo_antique");
  markedPhraseOnly.branches[0].phrases.push({
    id: "antique-highlight-phrase",
    text: "an antique vase",
    meaning: "古董花瓶",
    highlight: true,
    level: "tricky",
  });
  store.save(markedPhraseOnly);
  const s = page("setup");
  s.onLoad();
  s.onShow();
  s.flag(event({ key: "shuffle" }, false));
  s.flag(event({ key: "onlyHighlights" }, true));
  assert.equal(s.data.selectedCount, 2);
  s.start();
  assert.deepEqual(
    store.read().session.queue.map((q) => q.text),
    ["ancient", "in ancient times", "ancient buildings", "modern"],
  );
  s.chooseSelectionMode(event({ mode: "custom" }));
  s.openPicker(event({ kind: "words" }));
  s.selectSearchResults(event({ action: "add" }));
  s.closePicker();
  assert.equal(s.data.pickedCount, 3);
  assert.equal(s.data.selectedCount, 2);
  assert.equal(s.data.excludedCount, 1);
  s.start();
  const q = page("quiz");
  const shown = [];
  q.onShow();
  while (q.data.current) {
    shown.push(q.data.current.text);
    q.reveal();
    q.setData({ busy: false });
    q.answer(event({ rating: "known" }));
  }
  assert.deepEqual(shown, [
    "ancient",
    "in ancient times",
    "ancient buildings",
    "modern",
  ]);
  s.flag(event({ key: "onlyHighlights" }, false));
  assert.equal(s.data.selectedCount, 3);
  assert.equal(s.data.excludedCount, 0);
  s.start();
  assert.ok(
    store
      .read()
      .session.queue.some(
        (question) => question.text === "an ancient Greek philosopher",
      ),
  );
  assert.ok(
    store
      .read()
      .session.queue.some((question) => question.text === "an antique vase"),
  );
});

test("大量词条分批展示，全选搜索结果包含未展示项；删词或改词根后不误选其他单词", () => {
  store.importWords(
    Array.from({ length: 130 }, (_, i) =>
      m.validateWord({
        ...m.blankWord(),
        id: "word-" + i,
        text: "word-" + i,
        list: "Word List 1",
        branches: [
          {
            id: "b-" + i,
            pos: "n.",
            meanings: [i < 65 ? "前半" : "后半"],
            phrases: [],
          },
        ],
      }),
    ),
  );
  const s = page("setup");
  s.onLoad();
  s.onShow();
  s.chooseSelectionMode(event({ mode: "custom" }));
  s.openPicker(event({ kind: "words" }));
  assert.equal(s.data.pickerRows.length, 60);
  assert.equal(s.data.pickerTotal, 130);
  s.morePickerRows();
  assert.equal(s.data.pickerRows.length, 120);
  s.morePickerRows();
  assert.equal(s.data.pickerRows.length, 130);
  assert.equal(s.data.pickerHasMore, false);
  s.pickerSearch(event({}, "后半"));
  assert.equal(s.data.pickerRows.length, 60);
  assert.equal(s.data.pickerTotal, 65);
  s.selectSearchResults(event({ action: "add" }));
  assert.equal(s.data.pickedCount, 65);
  s.pickerSearch(event({}, "#70"));
  assert.equal(s.data.pickerRows[0].id, "word-69");
  s.selectSearchResults(event({ action: "remove" }));
  assert.equal(s.data.pickedCount, 64);
  s.closePicker();
  store.remove("word-65");
  const edited = store.get("word-66");
  edited.root = "new-root";
  store.save(edited);
  s.onShow();
  assert.equal(s.data.pickedCount, 63);
  assert.equal(s.data.segments[0].startText, "word-66");
  assert.equal(s.data.segments[0].startNumber, 66);
  assert.ok(!s.opts().wordIds.includes("word-69"));
  assert.ok(!s.opts().wordIds.includes("word-64"));
});

test("答案在当前抽查页展开；详情仅由用户主动打开，下一题不提前泄漏答案", () => {
  const h = page("home");
  h.demo();
  const s = page("setup");
  s.onLoad({});
  s.onShow();
  selectSingleWord(s, "demo_ancient");
  s.flag(event({ key: "shuffle" }, false));
  s.start();
  const q = page("quiz");
  q.onShow();
  const first = q.data.current.id;
  q.reveal();
  assert.equal(navigation.length, 1);
  assert.match(navigation[0], /pages\/quiz\/quiz/);
  q.onShow();
  assert.equal(q.data.current.id, first);
  assert.equal(q.data.revealed, true);
  q.detail();
  assert.match(navigation.at(-1), /from=quiz/);
  q.answer(event({ rating: "known" }));
  assert.equal(q.data.session.index, 1);
  assert.equal(q.data.revealed, false);
});

test("详情可分别设置单词和短语难度，目录显示单词分级，最低筛选只出合格内容", () => {
  page("home").demo();
  const d = page("detail");
  d.onLoad({ id: "demo_ancient" });
  d.onShow();
  assert.equal(d.data.word.level, "normal");
  d.chooseLevel(event({}, "tricky"));
  assert.equal(d.data.word.level, "tricky");
  const phrase = d.data.word.branches[0].phrases[0];
  d.choosePhraseLevel({ detail: { phraseId: phrase.id, level: "stubborn" } });
  assert.equal(d.data.word.branches[0].phrases[0].level, "stubborn");
  assert.equal(d.data.word.level, "tricky");
  const l = page("library");
  l.onShow();
  const word = l.data.groups
    .flatMap((g) => g.roots.flatMap((r) => r.words))
    .find((w) => w.id === d.id);
  assert.equal(word.level, "tricky");
  assert.equal(word.levelLabel, "Tricky");
  d.chooseLevel(event({}, "normal"));
  l.filter(event({ id: "difficult" }));
  assert.equal(l.data.count, 1, "单词 Normal 但短语需加强仍可检索到词条");
  const h = page("home");
  h.onShow();
  assert.equal(h.data.needsWork, 1);
  h.review(event({ minLevel: "shaky" }));
  assert.equal(navigation.at(-1), "/pages/setup/setup?minLevel=shaky");
  const s = page("setup");
  s.onLoad({ minLevel: "shaky" });
  s.onShow();
  assert.equal(s.data.total, 1);
  s.chooseLevel(event({}, "normal"));
  assert.equal(s.data.total, 3);
  s.chooseLevel(event({}, "stubborn"));
  assert.equal(s.data.total, 1);
  s.start();
  assert.ok(
    store
      .read()
      .session.queue.every(
        (q) => q.type === "phrase" && q.phraseId === phrase.id,
      ),
  );
});

test("编辑词条的旧草稿不会覆盖新学习分级，新单词和新增短语默认 Normal", () => {
  page("home").demo();
  const e = page("edit");
  e.onLoad();
  app.editWordId = "demo_ancient";
  e.onShow();
  const phraseId = e.data.word.branches[0].phrases[0].id;
  store.setLevel("demo_ancient", "shaky");
  store.setLevel("demo_ancient", "tricky", phraseId);
  e.field(event({ key: "note" }, "更新备注"));
  e.save();
  assert.equal(store.get("demo_ancient").level, "shaky");
  assert.equal(
    store.get("demo_ancient").branches[0].phrases[0].level,
    "tricky",
  );
  assert.equal(e.data.word.level, "normal");
  e.addPhrase(event({ branch: 0 }));
  assert.equal(e.data.word.branches[0].phrases[0].level, "normal");
});

test("抽查上一个显示原答案及评价，下一个回到未答题，暂停恢复回看位置", () => {
  page("home").demo();
  const s = page("setup");
  s.onLoad({});
  s.onShow();
  selectSingleWord(s, "demo_ancient");
  s.flag(event({ key: "shuffle" }, false));
  s.start();
  const q = page("quiz");
  q.onShow();
  q.previous();
  assert.equal(q.data.currentIndex, 0);
  q.reveal();
  q.answer(event({ rating: "wrong" }));
  q.setData({ busy: false });
  const word = store.get("demo_ancient");
  assert.equal(word.level, "shaky");
  assert.equal(q.data.level, "normal", "下一题短语有独立难度");
  q.previous();
  assert.equal(q.data.currentIndex, 0);
  assert.equal(q.data.reviewing, true);
  assert.equal(q.data.ratingLabel, "没记住");
  assert.equal(q.data.level, "shaky");
  assert.equal(q.data.revealed, true);
  q.setData({ busy: false });
  q.answer(event({ rating: "wrong" }));
  assert.deepEqual(store.get("demo_ancient"), word);
  q.home();
  assert.equal(navigation.at(-1), "/pages/home/home");
  const resumed = page("quiz");
  resumed.onShow();
  assert.equal(resumed.data.currentIndex, 0);
  resumed.next();
  assert.equal(resumed.data.reviewing, false);
  assert.equal(resumed.data.currentIndex, 1);
  assert.equal(resumed.data.revealed, false);
  assert.equal(store.read().session.ratings.length, 1);
  resumed.setData({ busy: false });
  resumed.next();
  assert.equal(store.read().session.ratings.length, 2);
  assert.equal(store.read().session.ratings[1].rating, "skip");
});
test("设置升降档分别勾选并传入本轮，暂停恢复及回看沿用本轮规则", () => {
  page("home").demo();
  const id = "demo_ancient";
  store.setLevel(id, "tricky");
  const phraseId = store.get(id).branches[0].phrases[0].id;
  store.setLevel(id, "shaky", phraseId);
  const s = page("setup");
  s.onLoad();
  s.onShow();
  assert.equal(s.data.autoUpgrade, true);
  assert.equal(s.data.autoDowngrade, false);
  selectSingleWord(s, id);
  s.flag(event({ key: "shuffle" }, false));
  s.flag(event({ key: "repeatDifficult" }, false));
  s.flag(event({ key: "autoDowngrade" }, true));
  assert.equal(s.data.autoUpgrade, true);
  s.flag(event({ key: "autoUpgrade" }, false));
  assert.equal(s.data.autoDowngrade, true);
  assert.equal(s.data.selectedCount, 1);
  s.start();
  assert.equal(store.read().session.autoUpgrade, false);
  assert.equal(store.read().session.autoDowngrade, true);
  s.flag(event({ key: "autoUpgrade" }, true));
  s.flag(event({ key: "autoDowngrade" }, false));
  assert.equal(
    store.read().session.autoUpgrade,
    false,
    "修改下一轮设置不更改正在进行的一轮",
  );
  const q = page("quiz");
  q.onShow();
  assert.equal(q.data.autoLevelSummary, "答错不升档 · 答对降一档");
  q.reveal();
  q.answer(event({ rating: "known" }));
  assert.equal(store.get(id).level, "shaky");
  assert.equal(store.get(id).branches[0].phrases[0].level, "shaky");
  q.home();
  const resumed = page("quiz");
  resumed.onShow();
  assert.equal(resumed.data.autoLevelSummary, "答错不升档 · 答对降一档");
  resumed.reveal();
  resumed.answer(event({ rating: "wrong" }));
  assert.equal(store.get(id).branches[0].phrases[0].level, "shaky");
  assert.equal(store.get(id).branches[0].phrases[0].mistakes, 1);
  const before = store.get(id);
  resumed.setData({ busy: false });
  resumed.previous();
  resumed.setData({ busy: false });
  resumed.answer(event({ rating: "known" }));
  assert.deepEqual(store.get(id), before);
  assert.equal(store.read().session.ratings.length, 2);
});

test("编译后的 WXML 在空库、完整词条、筛选与结束态均可渲染", () => {
  global.window = {};
  const compiler = require("miniprogram-compiler");
  const render = new Function(
    "global",
    compiler.wxmlToJs(path.resolve(__dirname, "../miniprogram")),
  )({});
  const h = page("home");
  h.onShow();
  assert.ok(
    JSON.stringify(render("pages/home/home.wxml")(h.data)).includes(
      "载入图片示例",
    ),
  );
  h.demo();
  for (const name of ["home", "library", "edit", "setup", "backup"]) {
    const p = page(name);
    if (p.onLoad) p.onLoad({});
    if (p.onShow) p.onShow();
    const tree = render("pages/" + name + "/" + name + ".wxml")(p.data);
    assert.ok(tree.children.length > 0, name);
  }
  const library = page("library");
  library.onShow();
  const relatedOnly = store.get("demo_ancient");
  relatedOnly.related.push({
    text: "detail-only-related",
    type: "关联",
    page: "",
  });
  store.save(relatedOnly);
  library.onShow();
  const libraryTree = render("pages/library/library.wxml")(library.data);
  function findClass(node, name) {
    if (!node || typeof node !== "object") return null;
    if (
      node.attr &&
      String(node.attr.class || "")
        .split(" ")
        .includes(name)
    )
      return node;
    for (const child of node.children || []) {
      const found = findClass(child, name);
      if (found) return found;
    }
    return null;
  }
  const listNode = findClass(libraryTree, "list-directory");
  const rootNode = findClass(listNode, "root-directory");
  const wordNode = findClass(rootNode, "word-directory");
  const meaningNode = findClass(wordNode, "meaning-row");
  assert.ok(meaningNode, "词性与汉义嵌套在单词、词根、词表之下");
  assert.ok(JSON.stringify(meaningNode).includes("古代的"));
  assert.ok(JSON.stringify(meaningNode).includes("a."));
  assert.ok(JSON.stringify(libraryTree).includes("古老的"));
  assert.ok(!JSON.stringify(libraryTree).includes("ancient buildings"));
  assert.ok(!JSON.stringify(libraryTree).includes("detail-only-related"));
  const groupKey = library.data.groups[0].key;
  library.toggle(event({ key: groupKey }));
  assert.equal(
    findClass(
      render("pages/library/library.wxml")(library.data),
      "root-directory",
    ),
    null,
  );
  assert.ok(store.get("demo_ancient").branches[0].phrases.length > 0);
  const edit = page("edit");
  edit.onLoad();
  const editTree = JSON.stringify(render("pages/edit/edit.wxml")(edit.data));
  for (const label of [
    "音标",
    "真题考频",
    "单词记法",
    "出现在真题中",
    "这个词性是重点",
    "近义 / 反义 / 派生",
  ])
    assert.ok(!editTree.includes(label), label);
  assert.ok(editTree.includes("词根拆解、联想记忆..."));
  assert.ok(editTree.includes("wx-picker"));
  edit.openRoots();
  assert.ok(
    JSON.stringify(render("pages/edit/edit.wxml")(edit.data)).includes(
      "搜索词根字母或中文释义",
    ),
  );
  const w = store.get("demo_ancient");
  const detail = JSON.stringify(
    render("components/word-content/word-content.wxml")({
      word: w,
      phrase: "ancient_p1",
    }),
  );
  assert.ok(detail.includes("an ancient oak tree"));
  assert.ok(detail.includes("当前短语"));
  const pagedWord = store.get("demo_antique");
  const pageTree = JSON.stringify(
    render("components/word-content/word-content.wxml")({ word: pagedWord }),
  );
  assert.ok(pageTree.includes("P426"));
  assert.ok(!pageTree.includes("PP426"));
  const walk = (node) => [node, ...(node.children || []).flatMap(walk)];
  const radios = (tree) => walk(tree).filter((node) => node.tag === "wx-radio");
  const d = page("detail");
  d.onLoad({ id: w.id });
  d.onShow();
  for (const item of d.data.levels) {
    d.chooseLevel(event({}, item.value));
    const controls = radios(render("pages/detail/detail.wxml")(d.data));
    assert.equal(controls.length, 4);
    assert.deepEqual(
      controls.filter((r) => r.attr.checked).map((r) => r.attr.value),
      [item.value],
    );
  }
  const setup = page("setup");
  setup.onLoad({});
  setup.onShow();
  for (const autoUpgrade of [false, true])
    for (const autoDowngrade of [false, true]) {
      setup.flag(event({ key: "autoUpgrade" }, autoUpgrade));
      setup.flag(event({ key: "autoDowngrade" }, autoDowngrade));
      const nodes = walk(render("pages/setup/setup.wxml")(setup.data));
      const controls = nodes.filter(
        (n) => n.tag === "wx-switch" && n.attr.type === "checkbox",
      );
      assert.equal(controls.length, 2);
      assert.deepEqual(
        controls.map((n) => [n.attr["data-key"], n.attr.checked]),
        [
          ["autoUpgrade", autoUpgrade],
          ["autoDowngrade", autoDowngrade],
        ],
      );
      const minimumIndex = nodes.findIndex(
        (n) => n.attr && n.attr.bindchange === "chooseLevel",
      );
      const repeatIndex = nodes.findIndex(
        (n) => n.attr && n.attr["data-key"] === "repeatDifficult",
      );
      assert.ok(nodes.indexOf(controls[0]) > minimumIndex);
      assert.ok(
        nodes.indexOf(controls[1]) < repeatIndex,
        "两项勾选位于最低难度与加练之间",
      );
      setup.start();
      const q = page("quiz");
      q.onShow();
      const summary =
        (autoUpgrade ? "答错升一档" : "答错不升档") +
        " · " +
        (autoDowngrade ? "答对降一档" : "答对不降档");
      assert.ok(
        JSON.stringify(render("pages/quiz/quiz.wxml")(q.data)).includes(
          summary,
        ),
      );
      assert.ok(
        JSON.stringify(
          render("pages/quiz/quiz.wxml")({
            ...q.data,
            current: null,
            session: { ...q.data.session, completed: true },
          }),
        ).includes(summary),
      );
    }
  setup.flag(event({ key: "autoDowngrade" }, false));
  for (const item of setup.data.levels) {
    setup.chooseLevel(event({}, item.value));
    const controls = radios(render("pages/setup/setup.wxml")(setup.data));
    assert.equal(controls.length, 4);
    assert.deepEqual(
      controls.filter((r) => r.attr.checked).map((r) => r.attr.value),
      [item.value],
    );
  }
  setup.chooseSelectionMode(event({ mode: "custom" }));
  let setupTree = render("pages/setup/setup.wxml")(setup.data);
  assert.ok(!JSON.stringify(setupTree).includes("百分比"));
  assert.ok(
    walk(setupTree).find(
      (n) => n.tag === "wx-button" && n.attr.bindtap === "start",
    ).attr.disabled,
  );
  setup.openPicker(event({ kind: "start" }));
  setup.pickWord(event({ id: "demo_ancient" }));
  setupTree = render("pages/setup/setup.wxml")(setup.data);
  assert.ok(findClass(setupTree, "word-picker-overlay"));
  assert.ok(
    JSON.stringify(findClass(setupTree, "picker-title")).includes("选择终点"),
  );
  setup.pickWord(event({ id: "demo_modern" }));
  setup.addRange();
  setupTree = render("pages/setup/setup.wxml")(setup.data);
  assert.equal(findClass(setupTree, "word-picker-overlay"), null);
  assert.ok(
    JSON.stringify(findClass(setupTree, "selected-segment")).includes(
      "ancient",
    ),
  );
  assert.ok(
    JSON.stringify(findClass(setupTree, "selected-segment")).includes("modern"),
  );
  assert.ok(findClass(setupTree, "selection-notice"));
  assert.ok(
    !walk(setupTree).find(
      (n) => n.tag === "wx-button" && n.attr.bindtap === "start",
    ).attr.disabled,
  );
  setup.openPicker(event({ kind: "words" }));
  setup.pickerSearch(event({}, "#2"));
  setupTree = render("pages/setup/setup.wxml")(setup.data);
  const selectedRow = findClass(setupTree, "picker-word");
  assert.ok(selectedRow.attr.class.includes("selected"));
  assert.ok(JSON.stringify(selectedRow).includes("antique"));
  setup.closePicker();
  setup.chooseSelectionMode(event({ mode: "all" }));
  let component;
  global.Component = (config) => {
    component = config;
  };
  require("../miniprogram/components/word-content/word-content");
  const context = {
    data: clone(component.data),
    setData(update) {
      Object.assign(this.data, update);
    },
    triggerEvent(name, detail) {
      assert.equal(name, "phraselevelchange");
      d.choosePhraseLevel({ detail });
    },
  };
  const phraseId = d.data.word.branches[0].phrases[0].id;
  component.methods.choosePhraseLevel.call(
    context,
    event({ phraseId }, "tricky"),
  );
  component.observers.word.call(context, d.data.word);
  assert.equal(context.data.levelLabel, "Stubborn");
  const componentTree = render("components/word-content/word-content.wxml")({
    ...context.data,
    word: d.data.word,
    editableLevels: true,
  });
  const phraseControls = radios(componentTree);
  assert.equal(phraseControls.length, 20, "五条短语各有四个选项");
  assert.equal(phraseControls.filter((r) => r.attr.checked).length, 5);
  assert.equal(
    phraseControls.filter((r) => r.attr.checked)[0].attr.value,
    "tricky",
  );
  const readOnlyTree = render("components/word-content/word-content.wxml")({
    ...context.data,
    word: d.data.word,
    editableLevels: false,
  });
  assert.equal(radios(readOnlyTree).length, 0, "关联词速查只显示分级");
  const quiz = page("quiz");
  setup.setData({ minLevel: "normal", shuffle: false });
  setup.start();
  quiz.onShow();
  const firstTree = render("pages/quiz/quiz.wxml")(quiz.data);
  const previous = walk(firstTree).find(
    (node) => node.tag === "wx-button" && node.attr.bindtap === "previous",
  );
  assert.ok(previous.attr.disabled);
  assert.ok(findClass(firstTree, "pause-footer"), "暂停按钮单独位于底栏");
  const finished = JSON.stringify(
    render("pages/quiz/quiz.wxml")({
      session: { completed: true, wordCount: 3, queue: [] },
      known: 0,
      wrong: 0,
      skipped: 0,
      percent: 0,
    }),
  );
  assert.ok(finished.includes("又熟悉了一点"));
  const backup = page("backup");
  backup.preview(JSON.stringify(store.words()));
  const dialog = JSON.stringify(
    render("pages/backup/backup.wxml")(backup.data),
  );
  for (const label of [
    "出现重复单词，请选择操作：",
    "覆盖所有",
    "跳过所有",
    "取消本次导入",
  ])
    assert.ok(dialog.includes(label));
});
