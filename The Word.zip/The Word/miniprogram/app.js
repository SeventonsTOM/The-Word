App({
  onLaunch() {
    require("./utils/store").initialize();
  },
});
