const store = require("../../utils/store"),
  ui = require("../../utils/ui"),
  levels = require("../../utils/levels");
Page({
  data: {
    session: null,
    current: null,
    revealed: false,
    progress: 0,
    known: 0,
    wrong: 0,
    skipped: 0,
    percent: 0,
    busy: false,
    currentIndex: 0,
    reviewing: false,
    ratingLabel: "",
    level: "normal",
    levelLabel: "Normal",
    autoLevelSummary: "",
  },
  onShow() {
    this.refresh();
  },
  refresh() {
    ui.run(() => {
      const data = store.read(),
        session = data.session;
      const currentIndex = session
        ? Number.isInteger(session.reviewIndex)
          ? session.reviewIndex
          : session.index
        : 0;
      const current =
        session && !session.completed ? session.queue[currentIndex] : null;
      const previousRating =
        current && session.ratings.find((r) => r.questionId === current.id);
      const word = current && data.words.find((w) => w.id === current.wordId);
      const target =
        word &&
        (current.type === "phrase"
          ? word.branches
              .flatMap((b) => b.phrases)
              .find((p) => p.id === current.phraseId)
          : word);
      const level = target ? target.level : "normal";
      const same =
        this.data.current && current && this.data.current.id === current.id;
      const known = session
          ? session.ratings.filter((r) => r.rating === "known").length
          : 0,
        wrong = session
          ? session.ratings.filter((r) => r.rating === "wrong").length
          : 0,
        skipped = session
          ? session.ratings.filter((r) => r.rating === "skip").length
          : 0;
      this.setData({
        session,
        current,
        currentIndex,
        reviewing: !!session && currentIndex < session.index,
        ratingLabel: previousRating
          ? { known: "已记住", wrong: "没记住", skip: "已跳过" }[
              previousRating.rating
            ]
          : "",
        level,
        levelLabel: levels.LEVELS[levels.rank(level)].label,
        autoLevelSummary:
          (session && session.autoUpgrade === false
            ? "答错不升档"
            : "答错升一档") +
          " · " +
          (session && session.autoDowngrade === true
            ? "答对降一档"
            : "答对不降档"),
        revealed:
          !!current &&
          ((same && this.data.revealed) ||
            !!(previousRating && previousRating.rating !== "skip") ||
            !!(this.revealedIds && this.revealedIds.has(current.id))),
        progress: session
          ? Math.round((session.index / session.queue.length) * 100)
          : 0,
        known,
        wrong,
        skipped,
        percent:
          known + wrong ? Math.round((known / (known + wrong)) * 100) : 0,
      });
    });
  },
  reveal() {
    if (!this.data.current) return;
    this.revealedIds = this.revealedIds || new Set();
    this.revealedIds.add(this.data.current.id);
    this.setData({ revealed: true });
  },
  detail() {
    const q = this.data.current;
    ui.detail(
      q.wordId,
      "&from=quiz" +
        (q.phraseId ? "&phrase=" + encodeURIComponent(q.phraseId) : ""),
    );
  },
  answer(e) {
    if (this.data.busy || this.data.reviewing) return;
    const rating = e.currentTarget.dataset.rating;
    if (rating !== "skip" && !this.data.revealed) return;
    this.setData({ busy: true });
    const ok = ui.run(() => {
      store.answer(rating);
      return true;
    });
    if (ok) this.refresh();
    setTimeout(() => this.setData({ busy: false }), 350);
  },
  previous() {
    if (this.data.busy || this.data.currentIndex === 0) return;
    this.move(store.previous);
  },
  next() {
    if (this.data.reviewing) this.move(store.forward);
    else this.answer({ currentTarget: { dataset: { rating: "skip" } } });
  },
  move(action) {
    if (this.data.busy) return;
    this.setData({ busy: true });
    const ok = ui.run(() => {
      action();
      return true;
    });
    if (ok) this.refresh();
    setTimeout(() => this.setData({ busy: false }), 350);
  },
  home() {
    wx.switchTab({ url: "/pages/home/home" });
  },
  again() {
    wx.redirectTo({ url: "/pages/setup/setup" });
  },
});
