const store = require("../../utils/store"),
  model = require("../../utils/model"),
  ui = require("../../utils/ui"),
  options = require("../../utils/entry-options"),
  levels = require("../../utils/levels");
Page({
  data: {
    query: "",
    filter: "all",
    groups: [],
    count: 0,
    managing: false,
    managingName: "",
    managingCount: 0,
    nextListName: "",
    filters: [
      { id: "all", text: "全部" },
      { id: "highlight", text: "重点" },
      { id: "difficult", text: "需加强 · Shaky+" },
      { id: "mastered", text: "已掌握" },
    ],
  },
  onShow() {
    this.refresh();
  },
  search(e) {
    this.collapsed = new Set();
    this.setData({ query: e.detail.value });
    this.refresh();
  },
  filter(e) {
    this.collapsed = new Set();
    this.setData({ filter: e.currentTarget.dataset.id });
    this.refresh();
  },
  refresh() {
    ui.run(() => {
      const q = this.data.query.trim().toLowerCase(),
        f = this.data.filter;
      const allWords = store.words();
      const words = allWords.filter(
        (w) =>
          (!q ||
            [
              w.text,
              w.root,
              w.list,
              ...w.branches.flatMap((b) =>
                b.meanings.concat(
                  b.phrases.map((p) => p.text + " " + p.meaning),
                ),
              ),
            ]
              .join(" ")
              .toLowerCase()
              .includes(q)) &&
          (f === "all" ||
            (f === "highlight" && model.highlighted(w)) ||
            (f === "difficult" && levels.needsWork(w)) ||
            (f === "mastered" && w.mastered)),
      );
      const groups = [];
      const isExpanded = (key) => !(this.collapsed && this.collapsed.has(key));
      words.forEach((w) => {
        let list = groups.find((g) => g.name === w.list);
        if (!list) {
          const key = JSON.stringify(["list", w.list]);
          list = {
            key,
            name: w.list,
            roots: [],
            count: 0,
            expanded: isExpanded(key),
            totalCount: allWords.filter((word) => word.list === w.list).length,
          };
          groups.push(list);
        }
        let root = list.roots.find((r) => r.name === (w.root || "未分词根"));
        if (!root) {
          const name = w.root || "未分词根";
          const key = JSON.stringify(["root", w.list, name]);
          root = { key, name, words: [], expanded: isExpanded(key) };
          list.roots.push(root);
        }
        const key = JSON.stringify(["word", w.id]);
        root.words.push({
          key,
          id: w.id,
          text: w.text,
          expanded: isExpanded(key),
          highlight: model.highlighted(w),
          level: w.level,
          levelLabel: levels.LEVELS[levels.rank(w.level)].label,
          mastered: w.mastered,
          branches: w.branches.map((b) => ({
            id: b.id,
            pos: b.pos,
            meaningText: b.meanings.join("；"),
            highlight: b.highlight,
          })),
        });
        list.count++;
      });
      groups.sort((a, b) => options.compareLists(a.name, b.name));
      groups.forEach((g) =>
        g.roots.sort((a, b) => options.compareRoots(a.name, b.name)),
      );
      this.setData({ groups, count: words.length });
    });
  },
  toggle(e) {
    const key = e.currentTarget.dataset.key;
    if (!key) return;
    this.collapsed = this.collapsed || new Set();
    if (this.collapsed.has(key)) this.collapsed.delete(key);
    else this.collapsed.add(key);
    this.refresh();
  },
  open(e) {
    ui.detail(e.currentTarget.dataset.id);
  },
  manage(e) {
    const name = e.currentTarget.dataset.name,
      group = this.data.groups.find((item) => item.name === name);
    if (!group) return;
    this.setData({
      managing: true,
      managingName: name,
      managingCount: group.totalCount,
      nextListName: name,
    });
  },
  listNameInput(e) {
    this.setData({ nextListName: e.detail.value });
  },
  closeManager() {
    this.setData({ managing: false });
  },
  noop() {},
  renameList() {
    ui.run(() => {
      const result = store.renameList(
        this.data.managingName,
        this.data.nextListName,
      );
      this.setData({ managing: false });
      wx.showToast({ title: "已重命名为“" + result.name + "”", icon: "none" });
      this.refresh();
    });
  },
  deleteList() {
    const name = this.data.managingName,
      count = this.data.managingCount;
    wx.showModal({
      title: "删除整本词书？",
      content:
        "将永久删除“" +
        name +
        "”及其中 " +
        count +
        " 个单词。若正在抽查这些词，本轮也会结束。此操作无法撤销，请确认已经备份。",
      confirmText: "确认删除",
      confirmColor: "#ae4b48",
      success: (res) => {
        if (!res.confirm) return;
        ui.run(() => {
          const result = store.removeList(name);
          this.setData({ managing: false });
          wx.showToast({
            title: "已删除 " + result.count + " 个单词",
            icon: "none",
          });
          this.refresh();
        });
      },
    });
  },
  add() {
    wx.switchTab({ url: "/pages/edit/edit" });
  },
});
