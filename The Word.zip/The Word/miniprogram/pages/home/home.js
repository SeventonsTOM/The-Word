const store = require("../../utils/store");
const ui = require("../../utils/ui");
const model = require("../../utils/model");
const levels = require("../../utils/levels");
Page({
  data: {
    total: 0,
    mastered: 0,
    needsWork: 0,
    highlights: 0,
    today: 0,
    session: null,
    recent: [],
  },
  onShow() {
    ui.run(() => {
      const data = store.read(),
        words = data.words;
      const today = new Date().toDateString();
      this.setData({
        total: words.length,
        mastered: words.filter((w) => w.mastered).length,
        needsWork: words.filter(levels.needsWork).length,
        highlights: words.filter(model.highlighted).length,
        today: data.history
          .filter((h) => new Date(h.date).toDateString() === today)
          .reduce((n, h) => n + h.count, 0),
        session: data.session && !data.session.completed ? data.session : null,
        recent: words.slice(-3).reverse(),
      });
    });
  },
  review(e) {
    wx.navigateTo({
      url:
        "/pages/setup/setup" +
        (e.currentTarget.dataset.minLevel ? "?minLevel=shaky" : ""),
    });
  },
  resume() {
    wx.navigateTo({ url: "/pages/quiz/quiz" });
  },
  library() {
    wx.switchTab({ url: "/pages/library/library" });
  },
  add() {
    wx.switchTab({ url: "/pages/edit/edit" });
  },
  backup() {
    wx.navigateTo({ url: "/pages/backup/backup" });
  },
  open(e) {
    ui.detail(e.currentTarget.dataset.id);
  },
  demo() {
    ui.run(() => {
      const result = store.importWords(
        require("../../data/demo").map(model.validateWord),
      );
      wx.showToast({
        title: result.added ? "已加入 3 个示例单词" : "示例词条已存在",
        icon: "none",
      });
      this.onShow();
    });
  },
});
