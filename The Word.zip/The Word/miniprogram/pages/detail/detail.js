const store = require("../../utils/store"),
  ui = require("../../utils/ui"),
  { LEVELS } = require("../../utils/levels");
Page({
  data: {
    word: null,
    phrase: "",
    fromQuiz: false,
    relatedWord: null,
    levels: LEVELS,
  },
  onLoad(opts) {
    this.id = opts.id;
    this.setData({ phrase: opts.phrase || "", fromQuiz: opts.from === "quiz" });
  },
  onShow() {
    ui.run(() => {
      const word = store.get(this.id);
      this.setData({ word: word || null });
    });
  },
  flag(e) {
    ui.run(() => {
      store.flag(this.id, e.currentTarget.dataset.key);
      this.onShow();
    });
  },
  chooseLevel(e) {
    ui.run(() => {
      store.setLevel(this.id, e.detail.value);
      this.onShow();
    });
  },
  choosePhraseLevel(e) {
    ui.run(() => {
      store.setLevel(this.id, e.detail.level, e.detail.phraseId);
      this.onShow();
    });
  },
  edit() {
    getApp().editWordId = this.id;
    wx.switchTab({ url: "/pages/edit/edit" });
  },
  back() {
    wx.navigateBack();
  },
  related(e) {
    ui.run(() => {
      const text = e.currentTarget.dataset.text;
      const matches = store
        .words()
        .filter((w) => w.text.toLowerCase() === text.toLowerCase());
      const show = (w) => this.setData({ relatedWord: w });
      if (matches.length === 1) show(matches[0]);
      else if (matches.length > 1)
        wx.showActionSheet({
          itemList: matches.slice(0, 6).map((w) => w.list + " · " + w.text),
          success: (r) => show(matches[r.tapIndex]),
        });
      else
        wx.showModal({
          title: text,
          content: "这个关联词还没有录入词库。录入后即可在这里查看。",
          showCancel: false,
        });
    });
  },
  close() {
    this.setData({ relatedWord: null });
  },
  noop() {},
  remove() {
    wx.showModal({
      title: "删除这个单词？",
      content: "词义和短语也将删除。此操作无法撤销，请先确认已备份。",
      confirmText: "删除",
      confirmColor: "#aa5544",
      success: (r) => {
        if (r.confirm)
          ui.run(() => {
            store.remove(this.id);
            wx.navigateBack();
          });
      },
    });
  },
});
