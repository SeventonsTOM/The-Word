const store = require("../../utils/store"),
  model = require("../../utils/model"),
  ui = require("../../utils/ui"),
  { createImportPlan } = require("../../utils/import-plan");
Page({
  data: { text: "", count: 0, status: "", importing: false, conflict: null },
  onUnload() {
    this.importPlan = null;
  },
  onShow() {
    ui.run(() => this.setData({ count: store.words().length }));
  },
  input(e) {
    this.setData({ text: e.detail.value });
  },
  exportFile() {
    ui.run(() => {
      const data = store.read();
      const backup = {
        schemaVersion: 1,
        exportedAt: new Date().toISOString(),
        words: data.words,
      };
      const path =
        wx.env.USER_DATA_PATH + "/wordbook-backup-" + Date.now() + ".json";
      wx.getFileSystemManager().writeFile({
        filePath: path,
        data: JSON.stringify(backup, null, 2),
        encoding: "utf8",
        success: () => {
          this.setData({
            status: "备份文件已生成，请发送至文件传输助手或保存到其他位置。",
          });
          if (wx.shareFileMessage)
            wx.shareFileMessage({
              filePath: path,
              fileName: "The Word 备份.json",
              fail: (e) => {
                this.setData({
                  status:
                    "分享未完成，备份文件暂留在小程序本机目录。请重试导出，或使用复制备份。",
                });
              },
            });
          else this.copy();
        },
        fail: ui.error,
      });
    });
  },
  copy() {
    ui.run(() => {
      const text = JSON.stringify(
        {
          schemaVersion: 1,
          exportedAt: new Date().toISOString(),
          words: store.words(),
        },
        null,
        2,
      );
      wx.setClipboardData({
        data: text,
        success: () =>
          this.setData({
            status: "已复制备份。请粘贴到电脑文件或其他安全位置保存。",
          }),
        fail: ui.error,
      });
    });
  },
  choose() {
    if (this.data.importing) return;
    wx.chooseMessageFile({
      count: 1,
      type: "file",
      extension: ["json"],
      success: (r) => {
        const f = r.tempFiles[0];
        if (f.size > 8 * 1024 * 1024) {
          ui.error(new Error("文件超过 8MB，请拆分导入"));
          return;
        }
        wx.getFileSystemManager().readFile({
          filePath: f.path,
          encoding: "utf8",
          success: (res) => this.preview(res.data),
          fail: ui.error,
        });
      },
      fail: (e) => {
        if (!/cancel/.test(e.errMsg || "")) ui.error(e);
      },
    });
  },
  paste() {
    this.preview(this.data.text);
  },
  preview(text) {
    if (this.data.importing) return;
    ui.run(() => {
      if (text.length > 8 * 1024 * 1024)
        throw new Error("文本过大，请拆分导入");
      const incoming = model.parseImport(text);
      wx.showModal({
        title: "导入 " + incoming.length + " 个词条？",
        content:
          "新词将添加到词库。遇到重复单词时，可逐个选择覆盖或跳过，也可对本次剩余重复词应用同一操作。",
        confirmText: "确认导入",
        success: (r) => {
          if (r.confirm)
            ui.run(() => {
              this.importPlan = createImportPlan(store.words(), incoming);
              this.setData({ importing: true });
              this.advanceImport();
            });
        },
      });
    });
  },
  advanceImport() {
    try {
      const pending = this.importPlan.next();
      if (pending) {
        const summary = (w) => ({
          text: w.text,
          list: w.list,
          meaning: w.branches
            .map((b) => b.pos + " " + b.meanings.join("；"))
            .join(" / ")
            .slice(0, 260),
        });
        this.setData({
          conflict: {
            position: pending.position,
            total: pending.total,
            existing: summary(pending.existing),
            incoming: summary(pending.incoming),
          },
        });
        return;
      }
      const result = store.commitImport(this.importPlan);
      this.importPlan = null;
      this.setData({
        importing: false,
        conflict: null,
        text: "",
        status:
          "导入完成：新增 " +
          result.added +
          " 个，覆盖 " +
          result.overwritten +
          " 个，跳过 " +
          result.skipped +
          " 个。" +
          (result.cancelledSession
            ? "使用了被覆盖词条的未完成抽查已结束，请重新开始一轮。"
            : ""),
      });
      this.onShow();
    } catch (e) {
      this.importPlan = null;
      this.setData({
        importing: false,
        conflict: null,
        status: "导入未保存，原词库保持不变。",
      });
      ui.error(e);
    }
  },
  resolveConflict(e) {
    if (!this.importPlan || !this.data.conflict) return;
    this.importPlan.resolve(e.currentTarget.dataset.action);
    this.advanceImport();
  },
  cancelImport() {
    this.importPlan = null;
    this.setData({
      importing: false,
      conflict: null,
      status: "已取消本次导入，原词库保持不变。",
    });
  },
  noop() {},
  demo() {
    if (this.data.importing) return;
    ui.run(() => {
      const result = store.importWords(
        require("../../data/demo").map(model.validateWord),
      );
      this.setData({
        status:
          "示例新增 " +
          result.added +
          " 个，跳过重复 " +
          result.skipped +
          " 个。",
      });
      this.onShow();
    });
  },
});
