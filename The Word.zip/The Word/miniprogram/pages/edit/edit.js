const store = require("../../utils/store"),
  model = require("../../utils/model"),
  ui = require("../../utils/ui"),
  options = require("../../utils/entry-options");
const levels = require("../../utils/levels");
const DRAFT = "wordbook.draft.v1";
function form(w) {
  const copy = JSON.parse(JSON.stringify(w));
  copy.level = levels.fromWord(copy);
  delete copy.bomb;
  copy.branches.forEach((b) => {
    b.meaningText = b.meanings.join("；");
    b.phrases.forEach((p) => {
      p.level = levels.phraseLevel(p);
      p.mistakes = Number(p.mistakes) || 0;
    });
  });
  
  if (copy.mnemonic) {
    if (!(copy.note || "").includes(copy.mnemonic))
      copy.note = [copy.mnemonic, copy.note].filter(Boolean).join("\n");
    copy.mnemonic = "";
  }
  return copy;
}
Page({
  data: {
    word: form(model.blankWord()),
    editing: false,
    error: "",
    draftSaved: false,
    listOptions: [],
    listRange: ["＋ 新建词表"],
    listIndex: 0,
    posOptions: options.posOptions([]),
    rootOptions: [],
    filteredRoots: [],
    selectorOpen: false,
    selectorKind: "root",
    creating: false,
    searchRoot: "",
    newName: "",
    selectorError: "",
    desktop: false,
    focusedInput: "",
  },
  onLoad() {
    // 手机多行输入仍使用换行键；电脑使用原生确认键切换下一项。
    try {
      const device = wx.getDeviceInfo
        ? wx.getDeviceInfo()
        : wx.getSystemInfoSync();
      this.setData({
        desktop: ["windows", "mac", "devtools"].includes(device.platform),
      });
    } catch (_) {}
    ui.run(() => {
      const draft = wx.getStorageSync(DRAFT);
      if (draft && draft.word) {
        const restored = form(draft.word);
        restored.branches.forEach((b, i) => {
          if (typeof draft.word.branches[i].meaningText === "string")
            b.meaningText = draft.word.branches[i].meaningText;
        });
        this.setData({
          word: restored,
          editing: draft.editing,
          draftSaved: true,
        });
      }
      this.refreshChoices();
    });
  },
  onShow() {
    const id = getApp().editWordId;
    if (id) {
      getApp().editWordId = null;
      ui.run(() => {
        const w = store.get(id);
        if (w) {
          const load = () => {
            this.setData({
              word: form(w),
              editing: true,
              error: "",
              draftSaved: false,
            });
            this.refreshChoices();
            this.persist();
          };
          if (this.data.word.text && this.data.word.id !== id) {
            wx.showModal({
              title: "切换到编辑词条？",
              content: "当前录入页的草稿会被替换。取消可先保存草稿。",
              success: (r) => {
                if (r.confirm) load();
              },
            });
          } else load();
        }
      });
    }
    ui.run(() => this.refreshChoices());
  },
  onHide() {
    this.setData({ focusedInput: "" });
    this.persist();
  },
  inputFocus(e) {
    this.setData({ focusedInput: e.currentTarget.dataset.input });
  },
  inputBlur(e) {
    // 上一项的 blur 可能晚于下一项的 focus，不能清掉新焦点。
    if (this.data.focusedInput === e.currentTarget.dataset.input)
      this.setData({ focusedInput: "" });
    this.persist();
  },
  inputOrder() {
    const fields = ["text", "page"];
    this.data.word.branches.forEach((branch) => {
      fields.push("meaning-" + branch.id);
      branch.phrases.forEach((phrase) => {
        fields.push(
          "phrase-" + phrase.id + "-text",
          "phrase-" + phrase.id + "-meaning",
        );
      });
    });
    this.data.word.related.forEach((_, i) => {
      fields.push("related-" + i + "-text", "related-" + i + "-page");
    });
    fields.push("note");
    return fields;
  },
  inputConfirm(e) {
    if (this.data.selectorOpen) return;
    // confirm 带有当前完整值；不要通过删换行来猜测 Enter，避免破坏粘贴文本。
    this.field(e);
    this.persist();
    const fields = this.inputOrder();
    const index = fields.indexOf(e.currentTarget.dataset.input);
    if (index < 0) return;
    const next = fields[index + 1] || "";
    this.setData({ focusedInput: next });
    if (this.data.desktop && wx.pageScrollTo)
      wx.pageScrollTo({
        selector: "#entry-" + (next || "save"),
        offsetTop: -100,
        duration: 0,
      });
  },
  persist() {
    try {
      wx.setStorageSync(DRAFT, {
        word: this.data.word,
        editing: this.data.editing,
      });
      this.setData({ draftSaved: true });
    } catch (e) {
      this.setData({
        error: "草稿未保存，存储空间可能不足。请先备份。",
        draftSaved: false,
      });
    }
  },
  field(e) {
    const d = e.currentTarget.dataset;
    let path = "word." + d.key;
    if (d.branch !== undefined)
      path = "word.branches[" + d.branch + "]." + d.key;
    if (d.phrase !== undefined)
      path =
        "word.branches[" + d.branch + "].phrases[" + d.phrase + "]." + d.key;
    if (d.related !== undefined)
      path = "word.related[" + d.related + "]." + d.key;
    this.setData({ [path]: e.detail.value, draftSaved: false, error: "" });
  },
  refreshChoices() {
    const words = store.words(),
      w = this.data.word;
    const lists = options.names(words, "list", w.list);
    const roots = options.names(words, "root", w.root);
    const poses = options.posOptions(w.branches);
    this.setData({
      listOptions: lists,
      listRange: lists.concat("＋ 新建词表"),
      listIndex: Math.max(0, lists.indexOf(w.list)),
      rootOptions: roots,
      posOptions: poses,
      "word.branches": w.branches.map((b) => {
        const index = poses.findIndex((p) => p.value === b.pos);
        return Object.assign({}, b, {
          posIndex: Math.max(0, index),
          posLabel: index >= 0 ? poses[index].label : "",
        });
      }),
    });
    this.filterRoots();
  },
  chooseList(e) {
    const index = Number(e.detail.value);
    if (index === this.data.listRange.length - 1) {
      this.setData({
        selectorOpen: true,
        focusedInput: "",
        selectorKind: "list",
        creating: true,
        newName: "",
        selectorError: "",
      });
      return;
    }
    this.setData({
      "word.list": this.data.listOptions[index],
      listIndex: index,
      error: "",
    });
    this.persist();
  },
  choosePos(e) {
    const p = this.data.posOptions[Number(e.detail.value)];
    if (!p) return;
    const prefix = "word.branches[" + e.currentTarget.dataset.branch + "]";
    this.setData({
      [prefix + ".pos"]: p.value,
      [prefix + ".posLabel"]: p.label,
      [prefix + ".posIndex"]: Number(e.detail.value),
      error: "",
    });
    this.persist();
  },
  openRoots() {
    ui.run(() => {
      this.refreshChoices();
      this.setData({
        selectorOpen: true,
        focusedInput: "",
        selectorKind: "root",
        creating: false,
        searchRoot: "",
        selectorError: "",
      });
      this.filterRoots();
    });
  },
  rootSearch(e) {
    this.setData({ searchRoot: e.detail.value });
    this.filterRoots();
  },
  filterRoots() {
    const q = this.data.searchRoot.trim().toLowerCase();
    this.setData({
      filteredRoots: this.data.rootOptions.filter((name) =>
        name.toLowerCase().includes(q),
      ),
    });
  },
  selectRoot(e) {
    this.setData({
      "word.root": e.currentTarget.dataset.name || "",
      selectorOpen: false,
    });
    this.persist();
  },
  startCreateRoot() {
    this.setData({
      creating: true,
      newName: this.data.searchRoot.trim(),
      selectorError: "",
    });
  },
  nameInput(e) {
    this.setData({ newName: e.detail.value, selectorError: "" });
  },
  confirmName() {
    const name = this.data.newName.trim(),
      isList = this.data.selectorKind === "list";
    if (!name || name.length > (isList ? 100 : 200)) {
      this.setData({
        selectorError: isList
          ? "请填写 1–100 个字符的词表名称"
          : "请填写 1–200 个字符的词根名称",
      });
      return;
    }
    ui.run(() => {
      this.refreshChoices();
      const all = isList ? this.data.listOptions : this.data.rootOptions;
      const existing = all.find((n) => n.toLowerCase() === name.toLowerCase());
      this.setData({
        [isList ? "word.list" : "word.root"]: existing || name,
        selectorOpen: false,
        error: "",
      });
      this.refreshChoices();
      this.persist();
    });
  },
  closeSelector() {
    this.setData({ selectorOpen: false, selectorError: "" });
  },
  noop() {},
  addBranch() {
    const branches = this.data.word.branches.concat({
      id: model.uid("branch"),
      pos: "a.",
      meanings: [],
      meaningText: "",
      highlight: false,
      phrases: [],
    });
    this.setData({ "word.branches": branches });
    this.refreshChoices();
    this.persist();
  },
  removeBranch(e) {
    const branches = this.data.word.branches.slice();
    if (branches.length === 1) {
      wx.showToast({ title: "至少保留一个词性分支", icon: "none" });
      return;
    }
    this.confirm("删除这个词性分支及其短语？", () => {
      branches.splice(e.currentTarget.dataset.branch, 1);
      this.setData({ "word.branches": branches });
      this.persist();
    });
  },
  addPhrase(e) {
    const i = e.currentTarget.dataset.branch;
    const phrases = this.data.word.branches[i].phrases.concat({
      id: model.uid("phrase"),
      text: "",
      meaning: "",
      highlight: false,
      exam: false,
      level: "normal",
      mistakes: 0,
    });
    this.setData({ ["word.branches[" + i + "].phrases"]: phrases });
    this.persist();
  },
  removePhrase(e) {
    const d = e.currentTarget.dataset;
    this.confirm("删除这条短语？", () => {
      const phrases = this.data.word.branches[d.branch].phrases.slice();
      phrases.splice(d.phrase, 1);
      this.setData({ ["word.branches[" + d.branch + "].phrases"]: phrases });
      this.persist();
    });
  },
  addRelated() {
    this.setData({
      "word.related": this.data.word.related.concat({
        text: "",
        type: "关联",
        page: "",
      }),
    });
    this.persist();
  },
  removeRelated(e) {
    const related = this.data.word.related.slice();
    related.splice(e.currentTarget.dataset.related, 1);
    this.setData({ "word.related": related });
    this.persist();
  },
  confirm(content, fn) {
    wx.showModal({
      title: "确认操作",
      content,
      success: (r) => {
        if (r.confirm) fn();
      },
    });
  },
  reset() {
    this.confirm("清空当前草稿，开始录入新单词？已保存的词条不受影响。", () => {
      this.setData({
        word: form(model.blankWord()),
        editing: false,
        error: "",
        focusedInput: "",
      });
      this.refreshChoices();
      this.persist();
    });
  },
  save() {
    try {
      const w = JSON.parse(JSON.stringify(this.data.word));
      // 录入页不修改学习评级；编辑期间的作答/手动分级以词库最新值为准。
      const current = store.get(w.id);
      if (current) {
        w.level = current.level;
        w.mistakes = current.mistakes;
        w.mastered = current.mastered;
        const phrases = new Map(
          current.branches.flatMap((b) => b.phrases).map((p) => [p.id, p]),
        );
        w.branches.forEach((b) =>
          b.phrases.forEach((p) => {
            const saved = phrases.get(p.id);
            if (saved) {
              p.level = saved.level;
              p.mistakes = saved.mistakes;
            }
          }),
        );
      }
      w.branches.forEach((b) => {
        b.meanings = b.meaningText
          .split(/[；;\n]/)
          .map((x) => x.trim())
          .filter(Boolean);
        delete b.meaningText;
      });
      const saved = store.save(w);
      const next = model.blankWord();
      next.list = saved.list;
      next.root = saved.root;
      this.setData({
        word: form(next),
        editing: false,
        error: "",
        draftSaved: false,
        focusedInput: "",
      });
      this.refreshChoices();
      wx.removeStorageSync(DRAFT);
      ui.detail(saved.id);
    } catch (e) {
      this.setData({ error: e.message });
      wx.showModal({
        title: "请检查词条",
        content: e.message,
        showCancel: false,
      });
    }
  },
});
