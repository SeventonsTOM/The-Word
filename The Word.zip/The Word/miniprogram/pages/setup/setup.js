const store = require("../../utils/store"),
  model = require("../../utils/model"),
  ui = require("../../utils/ui"),
  options = require("../../utils/entry-options"),
  levels = require("../../utils/levels"),
  selection = require("../../utils/word-selection");
Page({
  data: {
    lists: [],
    total: 0,
    selectedCount: 0,
    includeMastered: false,
    onlyHighlights: false,
    minLevel: "normal",
    levels: levels.LEVELS,
    autoUpgrade: true,
    autoDowngrade: false,
    repeatDifficult: true,
    shuffle: true,
    selectionMode: "all",
    bookNames: [],
    bookName: "",
    bookIndex: 0,
    bookCount: 0,
    pickedCount: 0,
    excludedCount: 0,
    rangeStartId: "",
    rangeEndId: "",
    rangeStartLabel: "",
    rangeEndLabel: "",
    rangeCount: 0,
    rangeError: "",
    segments: [],
    segmentLimit: 12,
    segmentCount: 0,
    pickerOpen: false,
    pickerKind: "words",
    pickerQuery: "",
    pickerRows: [],
    pickerLimit: 60,
    pickerTotal: 0,
    pickerSelectedCount: 0,
    pickerHasMore: false,
    dragging: false,
  },
  onLoad(o = {}) {
    this.setData({
      minLevel: levels.LEVELS.some((l) => l.value === o.minLevel)
        ? o.minLevel
        : "normal",
    });
  },
  onShow() {
    ui.run(() => {
      this.words = store.words();
      const names = options.names(this.words, "list");
      const old = this.data.lists;
      this.setData({
        lists: names.map((name) => ({
          name,
          count: this.words.filter((w) => w.list === name).length,
          selected: old.length
            ? !!old.find((x) => x.name === name && x.selected)
            : true,
        })),
      });
      this.refresh();
    });
  },
  baseOpts() {
    const d = this.data;
    return {
      lists: d.lists.filter((l) => l.selected).map((l) => l.name),
      includeMastered: d.includeMastered,
      onlyHighlights: d.onlyHighlights,
      minLevel: d.minLevel,
      autoUpgrade: d.autoUpgrade,
      autoDowngrade: d.autoDowngrade,
      repeatDifficult: d.repeatDifficult,
      shuffle: d.shuffle,
      mode: "all",
    };
  },
  selectedIds(book = this.data.bookName) {
    this.selections = this.selections || new Map();
    if (!this.selections.has(book)) this.selections.set(book, new Set());
    return this.selections.get(book);
  },
  opts() {
    const opts = this.baseOpts();
    if (this.data.selectionMode === "custom") {
      opts.mode = "selected";
      opts.lists = this.data.bookNames.includes(this.data.bookName)
        ? [this.data.bookName]
        : [];
      opts.wordIds = Array.from(this.selectedIds());
    }
    return opts;
  },
  refresh() {
    const available = model.filterWords(this.words || [], this.baseOpts());
    this.eligibleIds = new Set(available.map((w) => w.id));
    const bookNames = this.data.lists
      .filter((l) => l.selected)
      .map((l) => l.name);
    const bookName = bookNames.includes(this.data.bookName)
      ? this.data.bookName
      : bookNames[0] || "";
    if (bookName !== this.data.bookName) this.clearEndpoints();
    this.rows = selection.bookRows(this.words || [], bookName);
    const present = new Set(this.rows.map((w) => w.id)),
      selected = this.selectedIds(bookName);
    selected.forEach((id) => {
      if (!present.has(id)) selected.delete(id);
    });
    const pickedCount = selected.size;
    const eligibleCount = this.rows.filter(
      (w) => selected.has(w.id) && this.eligibleIds.has(w.id),
    ).length;
    this.runs = selection.segments(this.rows, selected);
    const start = this.rows.find((w) => w.id === this.data.rangeStartId);
    const end = this.rows.find((w) => w.id === this.data.rangeEndId);
    this.setData({
      bookNames,
      bookName,
      bookIndex: Math.max(0, bookNames.indexOf(bookName)),
      bookCount: this.rows.length,
      total: available.length,
      pickedCount,
      excludedCount: pickedCount - eligibleCount,
      selectedCount:
        this.data.selectionMode === "custom" ? eligibleCount : available.length,
      segments: this.runs.slice(0, this.data.segmentLimit),
      segmentCount: this.runs.length,
      rangeStartId: start ? start.id : "",
      rangeEndId: end ? end.id : "",
      rangeStartLabel: start ? "#" + start.number + " " + start.text : "",
      rangeEndLabel: end ? "#" + end.number + " " + end.text : "",
      rangeCount: start && end ? Math.abs(start.number - end.number) + 1 : 0,
    });
    if (this.data.pickerOpen) this.renderPicker();
  },
  toggle(e) {
    if (Date.now() < (this.suppressTapUntil || 0)) return;
    const i = e.currentTarget.dataset.index;
    this.setData({
      ["lists[" + i + "].selected"]: !this.data.lists[i].selected,
    });
    this.refresh();
  },
  all() {
    const on = this.data.lists.some((l) => !l.selected);
    this.setData({
      lists: this.data.lists.map((l) => Object.assign({}, l, { selected: on })),
    });
    this.refresh();
  },
  flag(e) {
    this.setData({ [e.currentTarget.dataset.key]: e.detail.value });
    this.refresh();
  },
  chooseLevel(e) {
    this.setData({ minLevel: levels.normalize(e.detail.value) });
    this.refresh();
  },
  chooseSelectionMode(e) {
    this.setData({ selectionMode: e.currentTarget.dataset.mode });
    this.refresh();
  },
  chooseBook(e) {
    const name = this.data.bookNames[Number(e.detail.value)];
    if (!name || name === this.data.bookName) return;
    this.clearEndpoints();
    this.setData({ bookName: name, segmentLimit: 12 });
    this.refresh();
  },
  clearEndpoints() {
    this.setData({
      rangeStartId: "",
      rangeEndId: "",
      rangeError: "",
      pickerOpen: false,
    });
  },
  addRange() {
    try {
      const ids = selection.rangeIds(
        this.rows || [],
        this.data.rangeStartId,
        this.data.rangeEndId,
      );
      const selected = this.selectedIds();
      const before = selected.size;
      ids.forEach((id) => selected.add(id));
      this.clearEndpoints();
      this.refresh();
      wx.showToast({
        title: "新增选中 " + (selected.size - before) + " 个词",
        icon: "none",
      });
    } catch (e) {
      this.setData({ rangeError: e.message });
    }
  },
  removeSegment(e) {
    const run = (this.runs || []).find(
      (r) => r.id === e.currentTarget.dataset.id,
    );
    if (!run) return;
    selection
      .rangeIds(this.rows, run.startId, run.endId)
      .forEach((id) => this.selectedIds().delete(id));
    this.refresh();
  },
  moreSegments() {
    this.setData({ segmentLimit: this.data.segmentLimit + 12 });
    this.refresh();
  },
  clearSelection() {
    this.selectedIds().clear();
    this.clearEndpoints();
    this.refresh();
  },
  openPicker(e) {
    if (!this.data.bookName) return;
    this.setData({
      pickerOpen: true,
      pickerKind: e.currentTarget.dataset.kind,
      pickerQuery: "",
      pickerLimit: 60,
    });
    this.renderPicker();
  },
  pickerSearch(e) {
    this.setData({ pickerQuery: e.detail.value, pickerLimit: 60 });
    this.renderPicker();
  },
  renderPicker() {
    const rows = selection.searchRows(this.rows || [], this.data.pickerQuery),
      selected = this.selectedIds();
    this.matchingRows = rows;
    this.setData({
      pickerRows: rows.slice(0, this.data.pickerLimit).map((w) =>
        Object.assign({}, w, {
          selected: selected.has(w.id),
          eligible: this.eligibleIds.has(w.id),
          endpoint:
            w.id ===
            (this.data.pickerKind === "start"
              ? this.data.rangeStartId
              : this.data.rangeEndId),
        }),
      ),
      pickerTotal: rows.length,
      pickerSelectedCount: rows.filter((w) => selected.has(w.id)).length,
      pickerHasMore: rows.length > this.data.pickerLimit,
    });
  },
  morePickerRows() {
    if (!this.data.pickerHasMore) return;
    this.setData({ pickerLimit: this.data.pickerLimit + 60 });
    this.renderPicker();
  },
  pickWord(e) {
    const id = e.currentTarget.dataset.id;
    if (!(this.rows || []).some((w) => w.id === id)) return;
    if (this.data.pickerKind === "words") {
      const selected = this.selectedIds();
      if (selected.has(id)) selected.delete(id);
      else selected.add(id);
      this.refresh();
    } else if (this.data.pickerKind === "start") {
      this.setData({
        rangeStartId: id,
        rangeError: "",
        pickerKind: "end",
        pickerQuery: "",
        pickerLimit: 60,
      });
      this.refresh();
    } else {
      this.setData({ rangeEndId: id, rangeError: "", pickerOpen: false });
      this.refresh();
    }
  },
  selectSearchResults(e) {
    const selected = this.selectedIds(),
      add = e.currentTarget.dataset.action === "add";
    (this.matchingRows || []).forEach((w) => {
      if (add) selected.add(w.id);
      else selected.delete(w.id);
    });
    this.refresh();
  },
  closePicker() {
    this.setData({ pickerOpen: false });
  },
  noop() {},
  longpress(e) {
    const index = Number(e.currentTarget.dataset.index);
    this.dragValue = !this.data.lists[index].selected;
    this.dragLast = index;
    this.dragActive = true;
    this.setData({
      dragging: true,
      ["lists[" + index + "].selected"]: this.dragValue,
    });
    this.refresh();
    wx.createSelectorQuery()
      .in(this)
      .selectAll(".list-option")
      .boundingClientRect((rects) => {
        this.rects = rects;
      })
      .exec();
  },
  touchmove(e) {
    if (!this.dragActive || !this.rects) return;
    const touch = e.touches[0];
    const i = this.rects.findIndex(
      (r) =>
        touch.clientY >= r.top &&
        touch.clientY <= r.bottom &&
        touch.clientX >= r.left &&
        touch.clientX <= r.right,
    );
    if (i < 0 || i === this.dragLast) return;
    const lists = this.data.lists.slice();
    for (
      let n = Math.min(i, this.dragLast);
      n <= Math.max(i, this.dragLast);
      n++
    )
      lists[n] = Object.assign({}, lists[n], { selected: this.dragValue });
    this.dragLast = i;
    this.setData({ lists });
    this.refresh();
  },
  touchend() {
    if (this.dragActive) this.suppressTapUntil = Date.now() + 400;
    this.dragActive = false;
    this.rects = null;
    this.setData({ dragging: false });
  },
  start() {
    if (!this.data.selectedCount) {
      wx.showToast({ title: "请先选择符合条件的单词", icon: "none" });
      return;
    }
    const launch = () =>
      ui.run(() => {
        const session = model.buildSession(store.words(), this.opts());
        store.start(session);
        wx.navigateTo({ url: "/pages/quiz/quiz" });
      });
    ui.run(() => {
      const s = store.read().session;
      if (s && !s.completed)
        wx.showModal({
          title: "开始新一轮？",
          content:
            "上一轮尚未完成。开始新一轮将替换上次的复习进度，已有错词记录会保留。",
          success: (r) => {
            if (r.confirm) launch();
          },
        });
      else launch();
    });
  },
});
