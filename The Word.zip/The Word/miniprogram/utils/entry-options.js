function alphabetic(a, b) {
  const left = a.toLowerCase(),
    right = b.toLowerCase();
  return left < right ? -1 : left > right ? 1 : a < b ? -1 : a > b ? 1 : 0;
}
function compareLists(a, b) {
  const left = a.match(/(\d+)\D*$/),
    right = b.match(/(\d+)\D*$/);
  if (left && right && Number(left[1]) !== Number(right[1]))
    return Number(left[1]) - Number(right[1]);
  if (!!left !== !!right) return left ? -1 : 1;
  return alphabetic(a, b);
}
function compareRoots(a, b) {
  const key = (value) =>
    (value.match(/[a-z][a-z-]*/i) || [value])[0].toLowerCase();
  return alphabetic(key(a), key(b)) || alphabetic(a, b);
}
function names(words, key, current) {
  const values = words
    .map((w) => w[key])
    .concat(current || "")
    .filter(Boolean);
  return Array.from(new Set(values)).sort(
    key === "list" ? compareLists : compareRoots,
  );
}
const POS = [
  ["a.", "adjective", "形容词（adj.）"],
  ["ad.", "adverb", "副词（adv.）"],
  ["art.", "article", "冠词"],
  ["aux.v.", "auxiliary verb", "助动词"],
  ["conj.", "conjunction", "连词"],
  ["det.", "determiner", "限定词"],
  ["int.", "interjection", "感叹词（interj.）"],
  ["modal v.", "modal verb", "情态动词"],
  ["n.", "noun", "名词"],
  ["num.", "numeral", "数词"],
  ["part.", "particle", "小品词"],
  ["prep.", "preposition", "介词"],
  ["pron.", "pronoun", "代词"],
  ["v.", "verb", "动词"],
  ["v.link.", "linking verb", "系动词"],
  ["vi.", "intransitive verb", "不及物动词"],
  ["vt.", "transitive verb", "及物动词"],
].map(([value, english, chinese]) => ({
  value,
  english,
  label: value + " · " + chinese,
}));
// 下拉框按显示的英文名称（缩写）排序；已有词条的其他词性写法也可继续选择。
function posOptions(branches) {
  const options = POS.map((p) => Object.assign({}, p));
  (branches || []).forEach((b) => {
    if (b.pos && !options.some((p) => p.value === b.pos))
      options.push({ value: b.pos, label: b.pos + " · 已有词性" });
  });
  // 常见全写缩略格式都作为可选项，适配不同单词书。
  [
    ["adj.", "形容词"],
    ["adv.", "副词"],
    ["interj.", "感叹词"],
  ].forEach(([value, label]) => {
    if (!options.some((p) => p.value === value))
      options.push({ value, label: value + " · " + label });
  });
  return options.sort((a, b) => alphabetic(a.value, b.value));
}
module.exports = { alphabetic, compareLists, compareRoots, names, posOptions };
