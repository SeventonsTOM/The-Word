const LEVELS = [
  { value: "normal", label: "Normal", color: "#23834b" },
  { value: "shaky", label: "Shaky", color: "#9a7400" },
  { value: "tricky", label: "Tricky", color: "#c35b0b" },
  { value: "stubborn", label: "Stubborn", color: "#c43b3b" },
];

function normalize(value = "normal") {
  const level = typeof value === "string" ? value.trim().toLowerCase() : "";
  if (!LEVELS.some((item) => item.value === level))
    throw new Error("分级须为 Normal、Shaky、Tricky 或 Stubborn");
  return level;
}

function rank(level) {
  const value = normalize(level);
  return LEVELS.findIndex((item) => item.value === value);
}

function fromWord(word) {
  // 已有新分级优先，手动调低后不会被累计错误次数再次抬高。
  if (word.level !== undefined) return normalize(word.level);
  if (word.mastered) return "normal";
  // 旧版两次错误加入 Bomb；保留旧记录及手动标记的加强意图。
  const mistakes = Number(word.mistakes) || 0;
  const index = Math.min(
    3,
    Math.max(0, Math.floor(mistakes), word.bomb ? 2 : 0),
  );
  return LEVELS[index].value;
}

function phraseLevel(phrase) {
  // 旧版没有短语独立错误记录，不能把单词的错误次数摊给所有短语。
  return normalize(phrase.level);
}

function needsWork(word) {
  return (
    atLeast(word, "shaky") ||
    word.branches.some((b) => b.phrases.some((p) => rank(phraseLevel(p)) >= 1))
  );
}

function next(level) {
  return LEVELS[Math.min(rank(level) + 1, LEVELS.length - 1)].value;
}

function previous(level) {
  return LEVELS[Math.max(rank(level) - 1, 0)].value;
}

function atLeast(word, minimum = "normal") {
  return rank(fromWord(word)) >= rank(minimum);
}

module.exports = {
  LEVELS,
  normalize,
  rank,
  fromWord,
  phraseLevel,
  needsWork,
  next,
  previous,
  atLeast,
};
