const model = require("./model");
const { displayPage } = require("./page-number");
const levels = require("./levels");
const KEY = "wordbook.v1";
function initialize() {
  if (!wx.getStorageSync(KEY))
    write({ schemaVersion: 1, words: [], session: null, history: [] });
}
function read() {
  let data = wx.getStorageSync(KEY);
  if (!data) return { schemaVersion: 1, words: [], session: null, history: [] };
  if (Array.isArray(data.chunks)) {
    try {
      data = JSON.parse(
        data.chunks
          .map((key) => {
            const chunk = wx.getStorageSync(key);
            if (typeof chunk !== "string") throw new Error("missing chunk");
            return chunk;
          })
          .join(""),
      );
    } catch (e) {
      throw new Error("本地数据无法读取，请勿清除缓存；可从已有备份恢复");
    }
  }
  if (data.schemaVersion !== 1 || !Array.isArray(data.words))
    throw new Error("本地数据无法读取，请勿清除缓存，先导出备份");
  // 兼容旧缓存中的裸数字页码；之后任何保存都会落盘为统一格式。
  data.words.forEach((w) => {
    w.level = levels.fromWord(w);
    delete w.bomb;
    w.branches.forEach((b) =>
      b.phrases.forEach((p) => {
        p.level = levels.phraseLevel(p);
        p.mistakes = Number(p.mistakes) || 0;
      }),
    );
    w.page = displayPage(w.page);
    (w.related || []).forEach((r) => {
      r.page = displayPage(r.page);
    });
  });
  return data;
}
function write(data) {
  // 分块避开单个缓存条目的容量上限。先写新块，再切换索引，失败保留旧版本。
  const previous = wx.getStorageSync(KEY),
    text = JSON.stringify(data),
    chunks = [],
    generation = model.uid("data");
  try {
    for (let i = 0; i < text.length; i += 120000) {
      const key = KEY + "." + generation + "." + chunks.length;
      chunks.push(key);
      wx.setStorageSync(key, text.slice(i, i + 120000));
    }
    wx.setStorageSync(KEY, { schemaVersion: 1, chunks });
  } catch (e) {
    chunks.forEach((key) => {
      try {
        wx.removeStorageSync(key);
      } catch (_) {}
    });
    throw new Error(
      "保存失败，可能存储空间不足。旧数据已保留，请先导出备份，再重试",
    );
  }
  if (previous && Array.isArray(previous.chunks))
    previous.chunks.forEach((key) => {
      try {
        wx.removeStorageSync(key);
      } catch (_) {}
    });
}
function words() {
  return read().words;
}
function get(id) {
  return words().find((w) => w.id === id);
}
function save(word) {
  const w = model.validateWord(word),
    data = read();
  if (
    data.words.some(
      (x) =>
        x.id !== w.id &&
        x.list.toLowerCase() === w.list.toLowerCase() &&
        x.text.toLowerCase() === w.text.toLowerCase(),
    )
  )
    throw new Error("同一词表已存在这个单词，请编辑原词条");
  const i = data.words.findIndex((x) => x.id === w.id);
  if (i >= 0) data.words[i] = w;
  else data.words.push(w);
  write(data);
  return w;
}
function remove(id) {
  const data = read();
  data.words = data.words.filter((w) => w.id !== id);
  write(data);
}
function renameList(currentName, nextName) {
  const name = typeof nextName === "string" ? nextName.trim() : "";
  if (!name) throw new Error("词书名称不能为空");
  if (name.length > 100) throw new Error("词书名称不能超过 100 个字符");
  const data = read(),
    entries = data.words.filter((w) => w.list === currentName);
  if (!entries.length) throw new Error("这本词书已经不存在");
  if (
    data.words.some(
      (w) =>
        w.list !== currentName && w.list.toLowerCase() === name.toLowerCase(),
    )
  )
    throw new Error("已经存在同名词书，请换一个名称");
  entries.forEach((w) => {
    w.list = name;
    w.updatedAt = Date.now();
  });
  write(data);
  return { name, count: entries.length };
}
function removeList(name) {
  const data = read(),
    ids = new Set(data.words.filter((w) => w.list === name).map((w) => w.id));
  if (!ids.size) throw new Error("这本词书已经不存在");
  data.words = data.words.filter((w) => !ids.has(w.id));
  const cancelledSession = !!(
    data.session &&
    !data.session.completed &&
    data.session.queue.some((q) => ids.has(q.wordId))
  );
  if (cancelledSession) data.session = null;
  write(data);
  return { count: ids.size, cancelledSession };
}
function flag(id, key) {
  if (key !== "mastered") return;
  const w = get(id);
  if (!w) throw new Error("该词条已不存在");
  w[key] = !w[key];
  if (w.mastered) w.level = "normal";
  save(w);
}
function setLevel(id, value, phraseId) {
  const level = levels.normalize(value);
  const w = get(id);
  if (!w) throw new Error("该词条已不存在");
  const target = phraseId
    ? w.branches.flatMap((b) => b.phrases).find((p) => p.id === phraseId)
    : w;
  if (!target) throw new Error("该短语已不存在");
  target.level = level;
  if (level !== "normal") w.mastered = false;
  save(w);
}
function start(session) {
  const data = read();
  data.session = session;
  write(data);
}
function answer(rating) {
  const data = read(),
    s = data.session;
  if (!s || s.completed) return;
  if (Number.isInteger(s.reviewIndex) && s.reviewIndex < s.index)
    throw new Error("正在回看已答题，请先返回当前进度");
  if (!["known", "wrong", "skip"].includes(rating))
    throw new Error("无效的作答");
  const q = s.queue[s.index],
    w = data.words.find((x) => x.id === q.wordId);
  if (
    w &&
    (rating === "wrong" || (rating === "known" && s.autoDowngrade === true))
  ) {
    const target =
      q.type === "phrase"
        ? w.branches.flatMap((b) => b.phrases).find((p) => p.id === q.phraseId)
        : w;
    if (target) {
      if (rating === "wrong") {
        target.mistakes += 1;
        // 没有开关字段的旧抽查继续沿用答错升档、答对不降档。
        if (s.autoUpgrade !== false) target.level = levels.next(target.level);
        w.mastered = false;
      } else {
        target.level = levels.previous(target.level);
      }
      w.updatedAt = Date.now();
    }
  }
  s.ratings.push({ questionId: q.id, rating });
  s.index += 1;
  if (s.index >= s.queue.length) {
    s.completed = true;
    s.completedAt = Date.now();
    data.history.unshift({
      id: s.id,
      date: s.completedAt,
      count: s.queue.length,
      known: s.ratings.filter((r) => r.rating === "known").length,
    });
    data.history = data.history.slice(0, 90);
  }
  write(data);
}
function previous() {
  const data = read(),
    s = data.session;
  if (!s || s.completed) return;
  const index = Number.isInteger(s.reviewIndex) ? s.reviewIndex : s.index;
  if (index <= 0) return;
  s.reviewIndex = index - 1;
  write(data);
}
function forward() {
  const data = read(),
    s = data.session;
  if (!s || s.completed || !Number.isInteger(s.reviewIndex)) return;
  if (s.reviewIndex + 1 >= s.index) delete s.reviewIndex;
  else s.reviewIndex += 1;
  write(data);
}
function importWords(incoming) {
  const data = read();
  const ids = new Set(data.words.map((w) => w.id)),
    names = new Set(
      data.words.map((w) => w.list.toLowerCase() + "\0" + w.text.toLowerCase()),
    );
  let added = 0,
    skipped = 0;
  incoming.forEach((w) => {
    const key = w.list.toLowerCase() + "\0" + w.text.toLowerCase();
    if (ids.has(w.id) || names.has(key)) {
      skipped++;
      return;
    }
    data.words.push(w);
    ids.add(w.id);
    names.add(key);
    added++;
  });
  write(data);
  return { added, skipped };
}
function commitImport(plan) {
  const result = plan.result(),
    data = read();
  if (JSON.stringify(data.words) !== result.base)
    throw new Error(
      "选择期间词库发生了变化，请重新导入，以免覆盖刚刚修改的内容。",
    );
  const replaced = new Set(result.replacedIds);
  const cancelledSession = !!(
    data.session &&
    !data.session.completed &&
    data.session.queue.some((q) => replaced.has(q.wordId))
  );
  data.words = result.words;
  if (cancelledSession) data.session = null;
  write(data);
  return Object.assign({}, result.counts, { cancelledSession });
}
module.exports = {
  initialize,
  read,
  words,
  get,
  save,
  remove,
  renameList,
  removeList,
  flag,
  setLevel,
  start,
  answer,
  previous,
  forward,
  importWords,
  commitImport,
};
