const DIGITS = {
  零: 0,
  〇: 0,
  一: 1,
  二: 2,
  两: 2,
  三: 3,
  四: 4,
  五: 5,
  六: 6,
  七: 7,
  八: 8,
  九: 9,
};
const SMALL_UNITS = { 十: 10, 百: 100, 千: 1000 };

function chineseNumber(text) {
  if (/^[零〇一二两三四五六七八九]+$/.test(text))
    return Number(
      Array.from(text)
        .map((c) => DIGITS[c])
        .join(""),
    );
  function section(s) {
    if (!s) return 0;
    let total = 0,
      digit = null,
      previousUnit = 10000;
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (Object.prototype.hasOwnProperty.call(DIGITS, c)) {
        const n = DIGITS[c];
        if (digit !== null && digit !== 0) throw new Error("数字顺序无效");
        digit = n;
      } else {
        const unit = SMALL_UNITS[c];
        if (!unit || unit >= previousUnit) throw new Error("数字单位无效");
        if (digit === null && !(unit === 10 && i === 0))
          throw new Error("数字单位前缺少数字");
        if (digit === 0) throw new Error("数字单位前不能为零");
        total += (digit === null ? 1 : digit) * unit;
        digit = null;
        previousUnit = unit;
      }
    }
    return total + (digit || 0);
  }
  const parts = text.split("万");
  if (parts.length > 2) throw new Error("数字单位重复");
  if (parts.length === 2) {
    if (!parts[0]) throw new Error("万前缺少数字");
    return section(parts[0]) * 10000 + section(parts[1]);
  }
  return section(text);
}

function normalizePage(value) {
  if (value === undefined || value === null || value === "") return "";
  if (typeof value !== "string" && typeof value !== "number")
    throw new Error("页码格式不正确");
  let s = String(value).trim();
  if (!s) return "";
  if (s.length > 30) throw new Error("页码过长");
  s = s
    .replace(/[０-９]/g, (c) => String(c.charCodeAt(0) - 0xff10))
    .replace(/^[pPＰｐ]\s*/, "")
    .replace(/^第\s*/, "")
    .replace(/\s*页$/, "")
    .trim();
  const variants = {
    壹: "一",
    贰: "二",
    貳: "二",
    叁: "三",
    參: "三",
    肆: "四",
    伍: "五",
    陆: "六",
    陸: "六",
    柒: "七",
    捌: "八",
    玖: "九",
    拾: "十",
    佰: "百",
    仟: "千",
    萬: "万",
    兩: "两",
  };
  s = s.replace(/[壹贰貳叁參肆伍陆陸柒捌玖拾佰仟萬兩]/g, (c) => variants[c]);
  try {
    const n = /^\d+$/.test(s) ? Number(s) : chineseNumber(s);
    if (!s || !Number.isSafeInteger(n) || n < 1) throw new Error("无效页码");
    return "P" + n;
  } catch (e) {
    throw new Error("页码请填写正整数，如 426、四百二十六或 P426");
  }
}
function displayPage(value) {
  try {
    return normalizePage(value);
  } catch (e) {
    return String(value || "");
  }
}
module.exports = { normalizePage, displayPage };
