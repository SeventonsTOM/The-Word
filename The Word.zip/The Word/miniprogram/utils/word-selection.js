// 序号只用于显示；选择始终按词条 ID 保存，避免删除或补录后选错词。
function bookRows(words, book) {
  return words
    .filter((w) => w.list === book)
    .map((w, index) => ({
      id: w.id,
      number: index + 1,
      text: w.text,
      page: w.page || "",
      meaning: w.branches
        .map((b) => b.pos + " " + b.meanings.join("；"))
        .join(" / ")
        .slice(0, 120),
    }));
}

function rangeIds(rows, startId, endId) {
  const start = rows.findIndex((w) => w.id === startId);
  const end = rows.findIndex((w) => w.id === endId);
  if (start < 0 || end < 0) throw new Error("请在当前词书中选择起点和终点");
  return rows
    .slice(Math.min(start, end), Math.max(start, end) + 1)
    .map((w) => w.id);
}

function searchRows(rows, query) {
  const q = query.trim().toLowerCase();
  if (!q) return rows;
  if (/^#?\d+$/.test(q)) {
    const number = Number(q.replace(/^#/, ""));
    return rows.filter((w) => w.number === number);
  }
  return rows.filter((w) =>
    [w.text, w.meaning, w.page].join(" ").toLowerCase().includes(q),
  );
}

function segments(rows, selected) {
  const result = [];
  let run = null;
  rows.forEach((row) => {
    if (!selected.has(row.id)) {
      run = null;
      return;
    }
    if (!run) {
      run = {
        id: row.id,
        startId: row.id,
        endId: row.id,
        startNumber: row.number,
        endNumber: row.number,
        startText: row.text,
        endText: row.text,
        count: 0,
      };
      result.push(run);
    }
    run.endId = row.id;
    run.endNumber = row.number;
    run.endText = row.text;
    run.count++;
  });
  return result;
}

module.exports = { bookRows, rangeIds, searchRows, segments };
