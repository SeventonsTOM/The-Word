各页面通用的逻辑部分

- [model.js](E:/The Word/miniprogram/utils/model.js)：词条校验、筛选条件和复习题队列生成。
- [store.js](E:/The Word/miniprogram/utils/store.js)：本地读写、学习状态、复习进度和导入提交。
- `levels.js`：Normal、Shaky、Tricky、Stubborn 四级难度规则。
- `word-selection.js`：自选词书里的单词、区间和搜索。
- `import-plan.js`：逐个处理导入重复项，整批选择完成后再保存。
- `entry-options.js`：词书排序、词根排序和词性选项。