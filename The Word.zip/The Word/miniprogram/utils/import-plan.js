const model = require("./model");

function nameKey(word) {
  return word.list.toLowerCase() + "\0" + word.text.toLowerCase();
}

// 在内存中逐条决定，完成整批选择后再一次性保存。
function createImportPlan(existing, incoming) {
  const words = JSON.parse(JSON.stringify(existing));
  const rows = incoming.map(model.validateWord);
  const byId = new Map(words.map((w, i) => [w.id, i]));
  const byName = new Map(words.map((w, i) => [nameKey(w), i]));
  const base = JSON.stringify(existing);
  const replacedIds = new Set();
  let cursor = 0,
    pending = null,
    all = null;
  const counts = { added: 0, overwritten: 0, skipped: 0 };

  function apply(action) {
    if (action === "overwrite") {
      const old = words[pending.index];
      byId.delete(old.id);
      byName.delete(nameKey(old));
      const replacement = Object.assign({}, pending.incoming, { id: old.id });
      words[pending.index] = replacement;
      byId.set(replacement.id, pending.index);
      byName.set(nameKey(replacement), pending.index);
      replacedIds.add(old.id);
      counts.overwritten++;
    } else counts.skipped++;
    cursor++;
    pending = null;
  }

  return {
    next() {
      if (pending) return pending;
      while (cursor < rows.length) {
        const word = rows[cursor];
        const idIndex = byId.get(word.id),
          nameIndex = byName.get(nameKey(word));
        if (
          idIndex !== undefined &&
          nameIndex !== undefined &&
          idIndex !== nameIndex
        )
          throw new Error(
            "词条“" +
              word.text +
              "”的 ID 和词名分别对应两个已有单词，请修正导入文件的 ID 后重试。本次导入尚未保存。",
          );
        const index = idIndex !== undefined ? idIndex : nameIndex;
        if (index === undefined) {
          byId.set(word.id, words.length);
          byName.set(nameKey(word), words.length);
          words.push(word);
          counts.added++;
          cursor++;
          continue;
        }
        pending = {
          index,
          existing: words[index],
          incoming: word,
          position: cursor + 1,
          total: rows.length,
        };
        if (!all) return pending;
        apply(all);
      }
      return null;
    },
    resolve(choice) {
      if (!pending) throw new Error("当前没有待处理的重复词");
      if (!["overwrite", "overwriteAll", "skip", "skipAll"].includes(choice))
        throw new Error("无效的重复词操作");
      if (choice === "overwriteAll") all = "overwrite";
      if (choice === "skipAll") all = "skip";
      apply(choice.startsWith("overwrite") ? "overwrite" : "skip");
    },
    result() {
      if (pending || cursor < rows.length)
        throw new Error("请先处理所有重复词");
      return {
        base,
        words,
        replacedIds: Array.from(replacedIds),
        counts: Object.assign({}, counts),
      };
    },
  };
}
module.exports = { createImportPlan };
