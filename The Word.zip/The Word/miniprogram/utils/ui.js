function error(e) {
  wx.showModal({
    title: "暂时未完成",
    content: e.message || String(e),
    showCancel: false,
  });
}
function run(fn) {
  try {
    return fn();
  } catch (e) {
    error(e);
    return undefined;
  }
}
function detail(id, extra) {
  wx.navigateTo({
    url: "/pages/detail/detail?id=" + encodeURIComponent(id) + (extra || ""),
  });
}
module.exports = { error, run, detail };
