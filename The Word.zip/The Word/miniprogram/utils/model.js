const { normalizePage } = require("./page-number");
const levels = require("./levels");
function uid(prefix) {
  return (
    (prefix || "id") +
    "_" +
    Date.now().toString(36) +
    "_" +
    Math.random().toString(36).slice(2, 10)
  );
}
function blankWord() {
  return {
    id: uid("word"),
    text: "",
    list: "",
    root: "",
    phonetic: "",
    frequency: 0,
    mnemonic: "",
    note: "",
    page: "",
    mastered: false,
    level: "normal",
    mistakes: 0,
    branches: [
      {
        id: uid("branch"),
        pos: "a.",
        meanings: [],
        highlight: false,
        phrases: [],
      },
    ],
    related: [],
    createdAt: Date.now(),
  };
}
function validateWord(w) {
  if (!w || typeof w !== "object" || Array.isArray(w))
    throw new Error("词条格式不正确");
  const str = (x, label, max = 4000) => {
    if (typeof x !== "string" || x.length > max)
      throw new Error(label + "格式不正确或过长");
    return x.trim();
  };
  const out = {
    id: str(w.id || uid("word"), "ID", 150),
    text: str(w.text, "英文", 200),
    list: str(w.list, "词表", 100),
    root: str(w.root || "", "词根", 200),
    phonetic: str(w.phonetic || "", "音标", 200),
    mnemonic: str(w.mnemonic || "", "记法"),
    note: str(w.note || "", "备注", 8001),
    page: normalizePage(w.page),
    frequency: Number(w.frequency || 0),
    mastered: !!w.mastered,
    level: levels.fromWord(w),
    mistakes: Number(w.mistakes || 0),
    createdAt: Number(w.createdAt) || Date.now(),
    updatedAt: Date.now(),
  };
  if (!out.id || !out.text || !out.list)
    throw new Error("请填写英文单词和词表");
  if (
    !Number.isInteger(out.frequency) ||
    out.frequency < 0 ||
    out.frequency > 100000
  )
    throw new Error("考频请填写非负整数");
  if (!Number.isInteger(out.mistakes) || out.mistakes < 0)
    throw new Error("错误次数格式不正确");
  if (
    !Array.isArray(w.branches) ||
    !w.branches.length ||
    w.branches.length > 100
  )
    throw new Error("请至少录入一条词性和汉义");
  const ids = new Set();
  function itemId(raw, prefix) {
    const id = str(raw || uid(prefix), "分支 ID", 150);
    if (!id || ids.has(id)) throw new Error("词性或短语 ID 重复");
    ids.add(id);
    return id;
  }
  out.branches = w.branches.map((b) => {
    if (
      !b ||
      !Array.isArray(b.meanings) ||
      !b.meanings.length ||
      b.meanings.length > 100
    )
      throw new Error("每个词性分支都需要汉义");
    const pos = str(b.pos, "词性", 30);
    const meanings = b.meanings.map((m) => str(m, "汉义", 1000));
    if (!pos || meanings.some((m) => !m)) throw new Error("词性和汉义不能为空");
    if (!Array.isArray(b.phrases) || b.phrases.length > 500)
      throw new Error("短语格式不正确");
    return {
      id: itemId(b.id, "branch"),
      pos,
      meanings,
      highlight: !!b.highlight,
      phrases: b.phrases.map((p) => {
        const text = str(p.text, "短语", 1000),
          meaning = str(p.meaning, "短语汉义", 1000);
        if (!text || !meaning) throw new Error("短语英文和汉义不能为空");
        const mistakes = Number(p.mistakes || 0);
        if (!Number.isInteger(mistakes) || mistakes < 0)
          throw new Error("短语错误次数格式不正确");
        return {
          id: itemId(p.id, "phrase"),
          text,
          meaning,
          highlight: !!p.highlight,
          exam: !!p.exam,
          level: levels.phraseLevel(p),
          mistakes,
        };
      }),
    };
  });
  if (!Array.isArray(w.related || []) || (w.related || []).length > 100)
    throw new Error("关联词格式不正确");
  out.related = (w.related || []).map((r) => ({
    text: str(r.text, "关联词", 200),
    type: str(r.type || "关联", "关联类型", 30),
    page: normalizePage(r.page),
  }));
  if (out.related.some((r) => !r.text)) throw new Error("关联词不能为空");
  return out;
}
function highlighted(w) {
  return w.branches.some(
    (b) => b.highlight || b.phrases.some((p) => p.highlight),
  );
}
function wordBranches(w, opts) {
  return levels.atLeast(w, opts.minLevel)
    ? w.branches.filter((b) => !opts.onlyHighlights || b.highlight)
    : [];
}
function phraseMatches(p, opts) {
  return (
    levels.rank(levels.phraseLevel(p)) >= levels.rank(opts.minLevel) &&
    (!opts.onlyHighlights || p.highlight)
  );
}
function filterWords(words, opts) {
  levels.normalize(opts.minLevel);
  if (
    opts.wordIds !== undefined &&
    (!Array.isArray(opts.wordIds) ||
      opts.wordIds.some((id) => typeof id !== "string"))
  )
    throw new Error("自选单词范围格式不正确");
  const selected = opts.wordIds === undefined ? null : new Set(opts.wordIds);
  return words.filter(
    (w) =>
      opts.lists.includes(w.list) &&
      (!selected || selected.has(w.id)) &&
      (opts.includeMastered || !w.mastered) &&
      // 仅重点先限定有重点词义的单词，短语再由 phraseMatches 单独检查重点。
      (!opts.onlyHighlights || w.branches.some((b) => b.highlight)) &&
      (wordBranches(w, opts).length > 0 ||
        w.branches.some((b) => b.phrases.some((p) => phraseMatches(p, opts)))),
  );
}
function shuffle(a, random = Math.random) {
  const out = a.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}
function buildSession(words, opts, random = Math.random) {
  if (
    opts.mode === "selected" &&
    (opts.lists.length !== 1 || !Array.isArray(opts.wordIds))
  )
    throw new Error("自选范围每次只能来自同一本词书");
  let pool = filterWords(words, opts);
  if (!pool.length) throw new Error("这个范围暂时没有可抽查的单词");
  let count = pool.length;
  // 新界面使用全部/自选；保留旧数量参数以兼容已有调用。
  if (opts.mode !== "all" && opts.mode !== "selected") {
    const raw = Number(opts.amount);
    if (
      !Number.isFinite(raw) ||
      raw <= 0 ||
      (opts.mode === "percent" && raw > 100) ||
      (opts.mode !== "percent" && !Number.isInteger(raw))
    )
      throw new Error("请输入有效的抽查数量或 1–100 的百分比");
    count =
      opts.mode === "percent"
        ? Math.ceil((pool.length * raw) / 100)
        : Math.min(raw, pool.length);
  }
  if (opts.shuffle) pool = shuffle(pool, random);
  pool = pool.slice(0, count);
  let queue = [];
  pool.forEach((w) => {
    const branches = wordBranches(w, opts);
    if (branches.length)
      queue.push({
        id: uid("question"),
        wordId: w.id,
        type: "word",
        text: w.text,
        answer: branches
          .map((b) => b.pos + " " + b.meanings.join("；"))
          .join("\n"),
        branchIds: branches.map((b) => b.id),
        repeat: false,
      });
    w.branches.forEach((b) =>
      b.phrases
        .filter((p) => phraseMatches(p, opts))
        .forEach((p) =>
          queue.push({
            id: uid("question"),
            wordId: w.id,
            type: "phrase",
            phraseId: p.id,
            text: p.text,
            answer: p.meaning,
            repeat: false,
          }),
        ),
    );
  });
  if (opts.shuffle) queue = shuffle(queue, random);
  // 以开局分级确定加练；每题最多追加一次，本轮升级不动态延长队列。
  if (opts.repeatDifficult)
    queue = queue.concat(
      queue
        .filter((q) => {
          const w = pool.find((word) => word.id === q.wordId);
          if (q.type === "word") return levels.atLeast(w, "shaky");
          const p = w.branches
            .flatMap((b) => b.phrases)
            .find((phrase) => phrase.id === q.phraseId);
          return levels.rank(levels.phraseLevel(p)) >= 1;
        })
        .map((q) =>
          Object.assign({}, q, { id: uid("question"), repeat: true }),
        ),
    );
  return {
    id: uid("session"),
    queue,
    index: 0,
    ratings: [],
    wordCount: pool.length,
    autoUpgrade: opts.autoUpgrade !== false,
    autoDowngrade: opts.autoDowngrade === true,
    startedAt: Date.now(),
    completed: false,
  };
}
function parseImport(text) {
  const data = JSON.parse(text);
  if (!Array.isArray(data) && (!data || data.schemaVersion !== 1))
    throw new Error("不支持的备份版本，请使用版本 1");
  const rows = Array.isArray(data) ? data : data.words;
  if (!Array.isArray(rows) || rows.length > 10000)
    throw new Error("导入文件必须包含 words 数组，最多 10000 个单词");
  const words = rows.map(validateWord),
    ids = new Set(),
    names = new Set();
  words.forEach((w) => {
    const key = w.list.toLowerCase() + "\0" + w.text.toLowerCase();
    if (ids.has(w.id) || names.has(key))
      throw new Error("导入文件存在重复 ID 或同词表重名单词");
    ids.add(w.id);
    names.add(key);
  });
  return words;
}
module.exports = {
  uid,
  blankWord,
  validateWord,
  highlighted,
  filterWords,
  shuffle,
  buildSession,
  parseImport,
};
