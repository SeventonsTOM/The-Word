const levels = require("../../utils/levels");
Component({
  properties: { word: Object, phrase: String, editableLevels: Boolean },
  options: { styleIsolation: "apply-shared" },
  data: { level: "normal", levelLabel: "Normal", levels: levels.LEVELS },
  observers: {
    word(word) {
      if (!word) return;
      const level = levels.fromWord(word);
      this.setData({
        level,
        levelLabel: levels.LEVELS[levels.rank(level)].label,
      });
    },
  },
  methods: {
    choosePhraseLevel(e) {
      this.triggerEvent("phraselevelchange", {
        phraseId: e.currentTarget.dataset.phraseId,
        level: e.detail.value,
      });
    },
  },
});
