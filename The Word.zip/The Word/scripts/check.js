const fs = require("node:fs"),
  path = require("node:path"),
  cp = require("node:child_process"),
  assert = require("node:assert/strict");
const root = path.resolve(__dirname, "../miniprogram");
function walk(dir) {
  return fs
    .readdirSync(dir, { withFileTypes: true })
    .flatMap((e) =>
      e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)],
    );
}
const files = walk(root);
for (const f of files) {
  if (f.endsWith(".js")) cp.execFileSync(process.execPath, ["--check", f]);
  if (f.endsWith(".json")) JSON.parse(fs.readFileSync(f, "utf8"));
}
const app = JSON.parse(fs.readFileSync(path.join(root, "app.json")));
for (const p of app.pages)
  for (const ext of ["js", "json", "wxml", "wxss"])
    assert.ok(
      fs.existsSync(path.join(root, p + "." + ext)),
      p + "." + ext + " missing",
    );
for (const f of files.filter((f) => f.endsWith(".wxml"))) {
  const js = f.replace(".wxml", ".js");
  const code = fs.readFileSync(js, "utf8");
  const xml = fs.readFileSync(f, "utf8");
  assert.ok(!/<br\b/.test(xml), "WXML does not support HTML br");
  for (const [, handler] of xml.matchAll(
    /(?:bind|catch)(?:tap|input|focus|blur|confirm|change|longpress|touchmove|touchend|touchcancel)="([a-zA-Z]+)"/g,
  ))
    assert.match(
      code,
      new RegExp("\\b" + handler + "\\s*\\("),
      f + ": missing handler " + handler,
    );
}
const { wxmlToJs, wxssToJs } = require("miniprogram-compiler");
const wxml = wxmlToJs(root);
assert.ok(wxml.length > 0);
const wxss = wxssToJs(root);
assert.ok(wxss.length > 0);
console.log(
  "PASS: JavaScript syntax, JSON, page files, event handlers, official WXML and WXSS compilation.",
);
